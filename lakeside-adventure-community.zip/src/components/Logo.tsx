import React from "react";

interface LogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
}

export default function Logo({ className = "", size = 48, showText = true }: LogoProps) {
  return (
    <div className={`flex items-center space-x-3 ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 400 400"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="drop-shadow-md hover:scale-105 transition-transform duration-300"
      >
        {/* Clip path for the Hexagon */}
        <defs>
          <clipPath id="hex-clip">
            <path d="M200 15 L360 108 L360 292 L200 385 L40 292 L40 108 Z" />
          </clipPath>
          
          {/* Sunset sky gradient */}
          <linearGradient id="sunset-gradient" x1="200" y1="15" x2="200" y2="385" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#C94A29" /> {/* Rich Red-Orange */}
            <stop offset="40%" stopColor="#E07A5F" /> {/* Warm Terracotta */}
            <stop offset="70%" stopColor="#F4A261" /> {/* Sunset Gold */}
            <stop offset="100%" stopColor="#E9C46A" /> {/* Yellow Sun */}
          </linearGradient>

          {/* Lake water gradient */}
          <linearGradient id="lake-gradient" x1="200" y1="210" x2="200" y2="245" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#3A86C8" />
            <stop offset="100%" stopColor="#1E4D75" />
          </linearGradient>
        </defs>

        {/* Outer Hexagon with Gold Border */}
        <path
          d="M200 10 L370 108 L370 292 L200 390 L30 292 L30 108 Z"
          fill="#0B2545"
          stroke="#E9C46A"
          strokeWidth="6"
          strokeLinejoin="round"
        />

        {/* Inner Border (Thin Gold) */}
        <path
          d="M200 18 L355 108 L355 282 L200 372 L45 282 L45 108 Z"
          stroke="#E9C46A"
          strokeWidth="2"
          strokeLinejoin="round"
        />

        {/* Hexagonal Content (Clipped) */}
        <g clipPath="url(#hex-clip)">
          {/* Background Gradient */}
          <path d="M40 15 L360 15 L360 385 L40 385 Z" fill="url(#sunset-gradient)" />

          {/* Sunrise/Sunset Glow Lines */}
          <circle cx="200" cy="180" r="140" fill="#F4A261" opacity="0.15" />
          <circle cx="200" cy="180" r="100" fill="#E9C46A" opacity="0.2" />

          {/* Crescent Moon */}
          <path
            d="M170 105 C170 143.66 138.66 175 100 175 C90 175 80.5 172.9 72 169.1 C91.5 183.5 115.8 192 142 192 C200 192 235 145 235 97 C235 73.8 225.5 52.8 210 37 C186.4 51.5 170 76.3 170 105 Z"
            fill="#FFFFFF"
            opacity="0.95"
            transform="translate(40, 20) scale(0.65)"
          />

          {/* Mountains Silhouette */}
          <path
            d="M30 220 L110 180 L160 205 L210 195 L270 220 Z"
            fill="#081C33"
          />

          {/* Lake Victoria Water */}
          <path
            d="M30 215 L370 215 L370 245 L30 245 Z"
            fill="url(#lake-gradient)"
          />
          
          {/* Soft Water Highlights */}
          <path d="M150 225 H250" stroke="#E9C46A" strokeWidth="2" strokeLinecap="round" opacity="0.6" />
          <path d="M110 233 H190" stroke="#4EA8DE" strokeWidth="1.5" strokeLinecap="round" opacity="0.8" />
          <path d="M210 233 H290" stroke="#4EA8DE" strokeWidth="1.5" strokeLinecap="round" opacity="0.8" />

          {/* Palm Tree Silhouette */}
          {/* Trunk */}
          <path
            d="M255 245 C252 205 262 160 295 130 C296 129 298 131 297 132 C268 160 258 205 260 245 Z"
            fill="#061629"
          />
          {/* Leaves */}
          {/* Leaf 1 (Left low) */}
          <path d="M295 130 C265 135 235 152 215 175 C230 155 260 142 295 130 Z" fill="#061629" />
          {/* Leaf 2 (Left mid) */}
          <path d="M295 130 C255 125 210 128 185 142 C210 133 255 130 295 130 Z" fill="#061629" />
          {/* Leaf 3 (Left high) */}
          <path d="M295 130 C265 110 225 100 198 105 C225 105 265 115 295 130 Z" fill="#061629" />
          {/* Leaf 4 (Top left) */}
          <path d="M295 130 C280 100 250 80 220 82 C245 88 275 105 295 130 Z" fill="#061629" />
          {/* Leaf 5 (Top right) */}
          <path d="M295 130 C300 95 315 80 338 85 C322 92 305 110 295 130 Z" fill="#061629" />
          {/* Leaf 6 (Right high) */}
          <path d="M295 130 C315 105 342 98 360 110 C340 110 315 118 295 130 Z" fill="#061629" />
          {/* Leaf 7 (Right low) */}
          <path d="M295 130 C320 125 345 135 352 155 C335 142 315 135 295 130 Z" fill="#061629" />

          {/* Deep Navy Bottom Third Banner */}
          <path d="M30 240 L370 240 L370 390 L30 390 Z" fill="#0B2545" />

          {/* LAKESIDE Text */}
          <text
            x="200"
            y="295"
            fill="#FFFFFF"
            fontSize="44"
            fontFamily="system-ui, -apple-system, sans-serif"
            fontWeight="800"
            textAnchor="middle"
            letterSpacing="3"
          >
            LAKESIDE
          </text>

          {/* Underline for LAKESIDE */}
          <line x1="100" y1="310" x2="300" y2="310" stroke="#FFFFFF" strokeWidth="3" />

          {/* ADVENTURES Text */}
          <text
            x="200"
            y="342"
            fill="#FFFFFF"
            fontSize="26"
            fontFamily="system-ui, -apple-system, sans-serif"
            fontWeight="700"
            textAnchor="middle"
            letterSpacing="5"
          >
            ADVENTURES
          </text>

          {/* Waves at the very bottom */}
          <path
            d="M 120 365 Q 140 360, 160 365 T 200 365 T 240 365 T 280 365"
            stroke="#FFFFFF"
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
          />
        </g>
      </svg>

      {showText && (
        <div className="flex flex-col select-none">
          <span className="font-sans font-black text-xl tracking-tight text-[#0B2545] leading-none uppercase">
            Lakeside
          </span>
          <span className="font-sans font-bold text-sm tracking-[0.25em] text-[#E76F51] leading-none mt-1 uppercase">
            Adventures
          </span>
          <span className="font-mono text-[9px] tracking-widest text-[#F4A261] font-bold uppercase mt-0.5">
            Eco • Wellness • Kisumu
          </span>
        </div>
      )}
    </div>
  );
}
