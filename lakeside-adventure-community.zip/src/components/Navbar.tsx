import React, { useState } from "react";
import { Compass, Menu, X, Calendar } from "lucide-react";
import Logo from "./Logo";

interface NavbarProps {
  onNavigate: (section: string) => void;
  activeSection: string;
  onOpenBooking: () => void;
  bookingCount: number;
}

export default function Navbar({ onNavigate, activeSection, onOpenBooking, bookingCount }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { id: "explore", label: "Explore Adventures" },
    { id: "calendar", label: "Adventure Calendar" },
    { id: "promise", label: "Our Promise" },
    { id: "impact", label: "Community & Eco-Impact" },
    { id: "faqs", label: "Travel FAQs" },
    { id: "my-bookings", label: "My Trips" }
  ];

  const handleNavClick = (id: string) => {
    onNavigate(id);
    setIsOpen(false);
  };

  return (
    <header id="site-header" className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div 
            id="navbar-logo"
            className="flex items-center cursor-pointer"
            onClick={() => handleNavClick("explore")}
          >
            <Logo size={52} showText={true} />
          </div>

          {/* Desktop Navigation */}
          <nav id="desktop-nav" className="hidden lg:flex space-x-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                id={`nav-link-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 cursor-pointer ${
                  activeSection === item.id
                    ? "bg-amber-50 text-[#C94A29] font-bold"
                    : "text-gray-600 hover:text-[#C94A29] hover:bg-gray-50"
                }`}
              >
                {item.id === "my-bookings" && bookingCount > 0 ? (
                  <span className="flex items-center space-x-1.5">
                    <span>{item.label}</span>
                    <span className="bg-[#E76F51] text-white text-[10px] w-5 h-5 flex items-center justify-center rounded-full font-bold">
                      {bookingCount}
                    </span>
                  </span>
                ) : (
                  item.label
                )}
              </button>
            ))}
          </nav>

          {/* Primary CTA */}
          <div className="hidden lg:flex items-center space-x-4">
            <button
              id="cta-check-availability"
              onClick={onOpenBooking}
              className="bg-[#E76F51] hover:bg-[#C94A29] text-white px-6 py-3 rounded-xl text-sm font-bold tracking-wide shadow-md shadow-orange-500/10 hover:shadow-orange-500/20 transition-all duration-200 cursor-pointer flex items-center space-x-2"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Your Tour</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center">
            <button
              id="mobile-menu-toggle"
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-lg text-gray-600 hover:text-[#C94A29] hover:bg-gray-100 focus:outline-hidden cursor-pointer"
              aria-label="Toggle Menu"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isOpen && (
        <div id="mobile-menu-drawer" className="lg:hidden bg-white border-b border-gray-100 animate-fadeIn">
          <div className="px-2 pt-2 pb-6 space-y-1 sm:px-3">
            {navItems.map((item) => (
              <button
                key={item.id}
                id={`mobile-nav-link-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`block w-full text-left px-4 py-3 rounded-xl text-base font-semibold transition-all ${
                  activeSection === item.id
                    ? "bg-amber-50 text-[#C94A29] font-bold"
                    : "text-gray-600 hover:text-[#C94A29] hover:bg-gray-50"
                }`}
              >
                {item.id === "my-bookings" && bookingCount > 0 ? (
                  <span className="flex items-center justify-between">
                    <span>{item.label}</span>
                    <span className="bg-[#E76F51] text-white text-xs px-2.5 py-1 rounded-full font-bold">
                      {bookingCount} active
                    </span>
                  </span>
                ) : (
                  item.label
                )}
              </button>
            ))}
            <div className="pt-4 px-4">
              <button
                id="mobile-cta-book-tour"
                onClick={() => {
                  setIsOpen(false);
                  onOpenBooking();
                }}
                className="w-full bg-[#E76F51] hover:bg-[#C94A29] text-white py-3.5 rounded-xl font-bold text-center shadow-lg shadow-orange-500/10 block transition-all cursor-pointer flex items-center justify-center space-x-2"
              >
                <Calendar className="w-5 h-5" />
                <span>Book Your Tour</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
