import React, { useState } from "react";
import { 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  MapPin, 
  Heart, 
  Leaf, 
  Sparkles,
  Award,
  Users,
  ExternalLink
} from "lucide-react";
import { Tour } from "../types";

interface AdventureCalendarProps {
  tours: Tour[];
  onSelectTour: (tour: Tour) => void;
  onOpenBooking: (tourId: string) => void;
}

interface ScheduledEvent {
  dayStart: number;
  dayEnd: number;
  tourId: string;
  spotsLeft: number;
  time: string;
}

export default function AdventureCalendar({ tours, onSelectTour, onOpenBooking }: AdventureCalendarProps) {
  // We'll support July, August, and September 2026
  const [currentMonthIndex, setCurrentMonthIndex] = useState(0); // 0 = July, 1 = August, 2 = September
  const [selectedDay, setSelectedDay] = useState<number | null>(12); // Default to 12 (matching current date July 12, 2026)

  const monthsData = [
    {
      name: "July",
      year: 2026,
      daysInMonth: 31,
      startDayOfWeek: 3, // Wednesday (0 = Sunday, 1 = Monday, etc.)
      events: [
        { dayStart: 4, dayEnd: 4, tourId: "got-ramogi-trek", spotsLeft: 6, time: "6:30 AM - 4:30 PM" },
        { dayStart: 11, dayEnd: 11, tourId: "kakamega-forest", spotsLeft: 3, time: "5:30 AM - 5:30 PM" },
        { dayStart: 17, dayEnd: 19, tourId: "rusinga-mfangano-escape", spotsLeft: 4, time: "3 Days / 2 Nights" },
        { dayStart: 25, dayEnd: 25, tourId: "nandi-cycling", spotsLeft: 8, time: "6:00 AM - 3:00 PM" }
      ] as ScheduledEvent[]
    },
    {
      name: "August",
      year: 2026,
      daysInMonth: 31,
      startDayOfWeek: 6, // Saturday
      events: [
        { dayStart: 1, dayEnd: 1, tourId: "simbi-nyaima-birding", spotsLeft: 10, time: "7:00 AM - 3:00 PM" },
        { dayStart: 8, dayEnd: 8, tourId: "got-ramogi-trek", spotsLeft: 12, time: "6:30 AM - 4:30 PM" },
        { dayStart: 14, dayEnd: 16, tourId: "rusinga-mfangano-escape", spotsLeft: 5, time: "3 Days / 2 Nights" },
        { dayStart: 22, dayEnd: 22, tourId: "kakamega-forest", spotsLeft: 7, time: "5:30 AM - 5:30 PM" },
        { dayStart: 29, dayEnd: 29, tourId: "nandi-cycling", spotsLeft: 9, time: "6:00 AM - 3:00 PM" }
      ] as ScheduledEvent[]
    },
    {
      name: "September",
      year: 2026,
      daysInMonth: 30,
      startDayOfWeek: 2, // Tuesday
      events: [
        { dayStart: 5, dayEnd: 5, tourId: "got-ramogi-trek", spotsLeft: 14, time: "6:30 AM - 4:30 PM" },
        { dayStart: 11, dayEnd: 13, tourId: "rusinga-mfangano-escape", spotsLeft: 6, time: "3 Days / 2 Nights" },
        { dayStart: 19, dayEnd: 19, tourId: "simbi-nyaima-birding", spotsLeft: 11, time: "7:00 AM - 3:00 PM" },
        { dayStart: 26, dayEnd: 26, tourId: "kakamega-forest", spotsLeft: 8, time: "5:30 AM - 5:30 PM" }
      ] as ScheduledEvent[]
    }
  ];

  const currentMonth = monthsData[currentMonthIndex];

  const handlePrevMonth = () => {
    if (currentMonthIndex > 0) {
      setCurrentMonthIndex(currentMonthIndex - 1);
      setSelectedDay(1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonthIndex < monthsData.length - 1) {
      setCurrentMonthIndex(currentMonthIndex + 1);
      setSelectedDay(1);
    }
  };

  // Helper to find events on a specific day
  const getEventForDay = (day: number) => {
    return currentMonth.events.find(
      (e) => day >= e.dayStart && day <= e.dayEnd
    );
  };

  // Helper to generate full list of days (with padding)
  const days = [];
  // Add empty cells for padding
  for (let i = 0; i < currentMonth.startDayOfWeek; i++) {
    days.push(null);
  }
  // Add actual days
  for (let i = 1; i <= currentMonth.daysInMonth; i++) {
    days.push(i);
  }

  // Get active selected event
  const selectedEvent = selectedDay ? getEventForDay(selectedDay) : null;
  const selectedTour = selectedEvent 
    ? tours.find((t) => t.id === selectedEvent.tourId) 
    : null;

  return (
    <div id="adventure-calendar-view" className="animate-fadeIn max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      {/* Title Header */}
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="font-mono text-xs font-bold text-[#E76F51] uppercase tracking-[0.2em] flex items-center justify-center gap-1.5">
          <CalendarIcon className="w-3.5 h-3.5" />
          <span>Interactive Dispatch Board</span>
        </span>
        <h1 className="text-3xl sm:text-4xl font-black text-[#0B2545] mt-3 tracking-tight">
          Monthly Adventure Calendar
        </h1>
        <p className="text-gray-600 mt-4 leading-relaxed">
          Planning your mental retreat is simple. Browse our fixed weekend departures for Summer & Autumn 2026. Select highlighted dates to view itinerary highlights, available slots, and to secure your pass.
        </p>
      </div>

      {/* Main Calendar Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-16">
        
        {/* Calendar Grid Box */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-gray-150 p-6 sm:p-8 shadow-md shadow-gray-150/40">
          
          {/* Calendar Header with Month/Year Toggles */}
          <div className="flex items-center justify-between mb-8 border-b border-gray-100 pb-5">
            <div className="flex items-center space-x-3">
              <div className="bg-[#E76F51]/10 text-[#E76F51] p-2.5 rounded-xl">
                <CalendarIcon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-[#0B2545]">
                  {currentMonth.name} {currentMonth.year}
                </h3>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">
                  {currentMonth.events.length} Scheduled Departures
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handlePrevMonth}
                disabled={currentMonthIndex === 0}
                className={`p-2.5 rounded-xl border border-gray-100 transition-all ${
                  currentMonthIndex === 0
                    ? "text-gray-300 bg-gray-50 cursor-not-allowed"
                    : "text-gray-600 hover:text-[#E76F51] hover:bg-amber-50/50 cursor-pointer"
                }`}
                title="Previous Month"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={handleNextMonth}
                disabled={currentMonthIndex === monthsData.length - 1}
                className={`p-2.5 rounded-xl border border-gray-100 transition-all ${
                  currentMonthIndex === monthsData.length - 1
                    ? "text-gray-300 bg-gray-50 cursor-not-allowed"
                    : "text-gray-600 hover:text-[#E76F51] hover:bg-amber-50/50 cursor-pointer"
                }`}
                title="Next Month"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Weekday Labels */}
          <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">
            <span>Sun</span>
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 gap-2">
            {days.map((day, idx) => {
              if (day === null) {
                return <div key={`empty-${idx}`} className="aspect-square bg-gray-50/30 rounded-xl" />;
              }

              const event = getEventForDay(day);
              const isSelected = selectedDay === day;
              
              let cellClass = "aspect-square flex flex-col justify-between p-2 rounded-xl border border-transparent font-bold text-sm transition-all select-none cursor-pointer relative ";
              
              if (event) {
                // Determine coloring based on adventure type
                const tour = tours.find(t => t.id === event.tourId);
                const isIsland = tour?.type.includes("Island");
                const isCycle = tour?.type.includes("Cycling");
                
                if (isSelected) {
                  cellClass += "bg-[#E76F51] text-white border-[#C94A29] shadow-md shadow-orange-500/25 scale-[1.03]";
                } else if (isIsland) {
                  cellClass += "bg-sky-50 text-sky-800 border-sky-200 hover:bg-sky-100/80";
                } else if (isCycle) {
                  cellClass += "bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100/80";
                } else {
                  cellClass += "bg-amber-50 text-[#C94A29] border-amber-200 hover:bg-amber-100/80";
                }
              } else {
                if (isSelected) {
                  cellClass += "bg-[#0B2545] text-white shadow-md";
                } else {
                  cellClass += "bg-gray-50/50 hover:bg-gray-100 text-gray-600 border-gray-100";
                }
              }

              return (
                <div
                  key={`day-${day}`}
                  onClick={() => setSelectedDay(day)}
                  className={cellClass}
                >
                  <span className="text-xs">{day}</span>
                  {event && (
                    <div className="flex justify-end">
                      <span className={`w-1.5 h-1.5 rounded-full ${isSelected ? "bg-white" : "bg-[#E76F51]"} animate-pulse`} />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Legend indicator */}
          <div className="flex flex-wrap items-center gap-4 mt-8 pt-6 border-t border-gray-100 text-xs text-gray-500">
            <span className="font-bold text-[#0B2545]">Departure Types:</span>
            <div className="flex items-center space-x-1.5">
              <span className="w-3 h-3 rounded-md bg-amber-50 border border-amber-200 block" />
              <span>Hikes & Treks</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-3 h-3 rounded-md bg-sky-50 border border-sky-200 block" />
              <span>Island Escapes</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-3 h-3 rounded-md bg-emerald-50 border border-emerald-200 block" />
              <span>Cycling Hikes</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-3 h-3 rounded-full bg-[#E76F51] block animate-pulse" />
              <span>Scheduled departure</span>
            </div>
          </div>
        </div>

        {/* Selected Day Sidebar Panel */}
        <div className="lg:col-span-5 space-y-6">
          {selectedTour && selectedEvent ? (
            <div className="bg-white rounded-3xl border border-gray-150 p-6 sm:p-8 shadow-md shadow-gray-150/40 space-y-6 animate-fadeIn">
              
              {/* Card visual banner */}
              <div className="relative h-44 rounded-2xl overflow-hidden bg-[#0B2545]">
                <img
                  src={selectedTour.image}
                  alt={selectedTour.title}
                  className="w-full h-full object-cover opacity-65"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B2545] via-transparent to-transparent" />
                <span className="absolute top-4 left-4 bg-[#E76F51] text-white px-3 py-1 rounded-xl text-[10px] font-bold tracking-wider uppercase shadow-sm">
                  {selectedTour.type}
                </span>
                
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <span className="text-[10px] uppercase font-bold text-amber-300 block">
                    Departure Date • {currentMonth.name} {selectedDay}, 2026
                  </span>
                  <h4 className="font-black text-lg leading-tight truncate">
                    {selectedTour.title}
                  </h4>
                </div>
              </div>

              {/* Specifics list */}
              <div className="grid grid-cols-2 gap-3 bg-gray-50 p-4 rounded-2xl border border-gray-100 text-xs">
                <div>
                  <span className="text-gray-400 font-bold block uppercase text-[9px]">Timing</span>
                  <span className="font-extrabold text-[#0B2545] flex items-center space-x-1 mt-0.5">
                    <Clock className="w-3.5 h-3.5 text-[#E76F51] shrink-0" />
                    <span className="truncate">{selectedEvent.time}</span>
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 font-bold block uppercase text-[9px]">Location</span>
                  <span className="font-extrabold text-[#0B2545] flex items-center space-x-1 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-[#E76F51] shrink-0" />
                    <span className="truncate">{selectedTour.location}</span>
                  </span>
                </div>
                <div className="pt-2 border-t border-gray-150/40">
                  <span className="text-gray-400 font-bold block uppercase text-[9px]">Pricing</span>
                  <span className="font-black text-emerald-700 text-sm block mt-0.5">
                    KES {selectedTour.priceKES.toLocaleString()}
                  </span>
                </div>
                <div className="pt-2 border-t border-gray-150/40">
                  <span className="text-gray-400 font-bold block uppercase text-[9px]">Availability</span>
                  <span className="font-bold text-red-600 flex items-center space-x-1 mt-0.5">
                    <Users className="w-3.5 h-3.5 shrink-0" />
                    <span>{selectedEvent.spotsLeft} Spots Left!</span>
                  </span>
                </div>
              </div>

              {/* Tagline / focus */}
              <p className="text-xs text-gray-500 italic leading-relaxed text-center border-t border-b border-gray-100 py-3">
                "{selectedTour.tagline}"
              </p>

              {/* Quick Wellness & Eco Impact bullet points */}
              <div className="space-y-3.5 text-xs text-gray-600">
                <div className="flex items-start space-x-3">
                  <Heart className="w-4 h-4 text-[#E76F51] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-[#0B2545] block">Mindfulness Practice</span>
                    <p className="text-gray-500 mt-0.5 text-[11px] leading-relaxed line-clamp-2">{selectedTour.wellnessFocus}</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Leaf className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-emerald-800 block">Conservation Contribution</span>
                    <p className="text-gray-500 mt-0.5 text-[11px] leading-relaxed line-clamp-2">{selectedTour.conservationImpact}</p>
                  </div>
                </div>
              </div>

              {/* Direct Actions */}
              <div className="grid grid-cols-2 gap-3 pt-4 border-t border-gray-100">
                <button
                  onClick={() => onSelectTour(selectedTour)}
                  className="bg-gray-100 hover:bg-gray-200 text-[#0B2545] font-bold text-xs py-3.5 rounded-xl transition-all text-center cursor-pointer uppercase tracking-wider"
                >
                  View Details
                </button>
                <button
                  onClick={() => onOpenBooking(selectedTour.id)}
                  className="bg-[#E76F51] hover:bg-[#C94A29] text-white font-bold text-xs py-3.5 rounded-xl transition-all text-center shadow-md shadow-orange-500/10 cursor-pointer uppercase tracking-wider"
                >
                  Book Seat
                </button>
              </div>

            </div>
          ) : (
            <div className="bg-gray-50 rounded-3xl border border-dashed border-gray-200 p-8 text-center h-[340px] flex flex-col items-center justify-center space-y-4">
              <CalendarIcon className="w-10 h-10 text-gray-350 animate-pulse" />
              <div>
                <h4 className="font-bold text-[#0B2545]">Select Scheduled Day</h4>
                <p className="text-xs text-gray-400 mt-2 max-w-xs leading-relaxed">
                  Click on any highlighted day inside the calendar grid (e.g. {currentMonth.events.map(e => e.dayStart).join(", ")}) to check departure times, available spots, and secure passes.
                </p>
              </div>
            </div>
          )}

          {/* Quick List of Month Departures */}
          <div className="bg-white rounded-3xl border border-gray-150 p-6 shadow-md shadow-gray-150/40 space-y-4">
            <h4 className="font-extrabold text-sm text-[#0B2545] border-b border-gray-50 pb-2 flex items-center space-x-1.5">
              <Sparkles className="w-4 h-4 text-[#F4A261]" />
              <span>Full {currentMonth.name} departures</span>
            </h4>

            <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
              {currentMonth.events.map((event, idx) => {
                const tour = tours.find(t => t.id === event.tourId);
                if (!tour) return null;
                const isSelected = selectedDay === event.dayStart;
                
                return (
                  <div
                    key={idx}
                    onClick={() => setSelectedDay(event.dayStart)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? "bg-amber-50/50 border-[#E76F51] shadow-xs"
                        : "bg-gray-50/40 border-gray-100 hover:bg-gray-50 hover:border-gray-200"
                    }`}
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="bg-[#E76F51] text-white w-9 h-9 rounded-lg flex flex-col items-center justify-center font-black text-xs shrink-0">
                        <span className="text-[8px] uppercase tracking-normal leading-none font-bold">Day</span>
                        <span className="leading-tight">{event.dayStart}</span>
                      </div>
                      <div className="min-w-0">
                        <span className="font-bold text-xs text-[#0B2545] block truncate leading-snug">
                          {tour.title}
                        </span>
                        <span className="text-[10px] text-gray-400 font-mono block mt-0.5">
                          {event.time} • {event.spotsLeft} spots left
                        </span>
                      </div>
                    </div>

                    <ChevronRight className={`w-4 h-4 text-gray-300 shrink-0 ${isSelected ? "text-[#E76F51]" : ""}`} />
                  </div>
                );
              })}
            </div>
          </div>

        </div>

      </div>

      {/* Prominent Google Reviews Integration Section */}
      <section id="google-reviews-banner" className="bg-[#0B2545] rounded-3xl p-8 sm:p-10 text-white relative overflow-hidden shadow-xl border border-white/5">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#E76F51]/15 rounded-full blur-3xl -z-10" />
        <div className="absolute bottom-0 left-0 w-60 h-60 bg-blue-500/5 rounded-full blur-3xl -z-10" />

        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
          
          <div className="space-y-4 max-w-xl">
            <span className="inline-flex items-center space-x-1.5 bg-white/10 border border-white/10 px-3 py-1 rounded-full text-[10px] font-bold tracking-widest uppercase text-amber-300">
              <Award className="w-3.5 h-3.5" />
              <span>Community Validation</span>
            </span>
            <h3 className="text-2xl sm:text-3xl font-black tracking-tight">
              We are Rated 4.9★ on Google Reviews
            </h3>
            <p className="text-sm text-amber-50/70 leading-relaxed">
              Our travelers speak for us. From breathtaking forest canopy treks to slow island sunsets on Lake Victoria, see how our focus on mental wellness and community impact leaves lasting footprints.
            </p>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 shrink-0 lg:max-w-sm flex flex-col justify-between space-y-5 backdrop-blur-xs">
            <div className="space-y-1.5">
              <div className="flex text-amber-400 text-lg">
                {"★".repeat(5)}
              </div>
              <p className="text-xs font-semibold text-white">
                "Kisumu's best-kept eco-wellness community! Restored my peace of mind entirely."
              </p>
              <span className="block text-[10px] text-amber-50/50">
                — Shared recently via Google Local Guides
              </span>
            </div>

            <a
              href="https://share.google/e4LG0nHHn4TwAVXR3"
              target="_blank"
              rel="noopener noreferrer referrer"
              className="bg-white hover:bg-amber-50 text-[#0B2545] font-bold text-xs py-3.5 px-6 rounded-xl transition-all text-center flex items-center justify-center space-x-2 shadow-lg shadow-black/10 cursor-pointer"
            >
              <span>Explore Verified Google Reviews</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

        </div>
      </section>

    </div>
  );
}
