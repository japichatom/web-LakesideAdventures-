export enum ActivityType {
  Hike = "Hike",
  Cycling = "Cycling",
  IslandEscape = "Island Escape",
  RegionalTrip = "Regional Trip"
}

export enum DifficultyLevel {
  Easy = "Easy",
  Moderate = "Moderate",
  Hard = "Hard"
}

export interface Tour {
  id: string;
  title: string;
  tagline: string;
  type: ActivityType;
  difficulty: DifficultyLevel;
  duration: string;
  location: string;
  priceKES: number;
  priceUSD: number;
  image: string;
  description: string;
  highlights: string[];
  wellnessFocus: string;
  conservationImpact: string;
  itinerary: { day: number; title: string; description: string }[];
  included: string[];
  notIncluded: string[];
  gearList: string[];
}

export interface Booking {
  id: string;
  tourId: string;
  tourTitle: string;
  tourImage: string;
  tourType: ActivityType;
  priceKES: number;
  date: string;
  guests: number;
  fullName: string;
  email: string;
  phone: string;
  paymentMethod: "MPESA" | "CARD";
  mpesaNumber?: string;
  specialRequests?: string;
  totalCostKES: number;
  bookingDate: string;
  status: "CONFIRMED" | "PENDING";
}

export interface Review {
  id: string;
  tourId: string;
  author: string;
  rating: number;
  date: string;
  comment: string;
  location: string;
  verified: boolean;
  likes: number;
}

export interface FAQ {
  id: string;
  category: "Logistics" | "Gear" | "Wellness" | "Impact" | "Booking";
  question: string;
  answer: string;
}

export interface ImpactStats {
  treesPlanted: number;
  wasteCollectedKG: number;
  guidesSupported: number;
  communityScholars: number;
}
