import { Tour, ActivityType, DifficultyLevel, FAQ, Review, ImpactStats } from "../types";

export const TOURS_DATA: Tour[] = [
  {
    id: "kakamega-forest",
    title: "Kakamega Forest Canopy Hike",
    tagline: "Unveil the ancient equatorial rainforest.",
    type: ActivityType.Hike,
    difficulty: DifficultyLevel.Moderate,
    duration: "1 Day (12 hours including travel)",
    location: "Kakamega Forest National Reserve",
    priceKES: 4500,
    priceUSD: 35,
    image: "https://images.unsplash.com/photo-1511497584788-876760111969?auto=format&fit=crop&w=1200&q=80",
    description: "An immersive forest bathing experience in East Africa's last remaining Guineo-Congolian rainforest. Led by expert indigenous naturalists, this hike takes you under the cover of 400-year-old trees, past crashing waterfalls, and to the breathtaking summit of Lirhanda Hill for an endless canopy view.",
    highlights: [
      "Guided forest bathing and sensory mindfulness exercises",
      "Climb Lirhanda Hill for a panoramic 360-degree canopy view",
      "Encounter rare primates including Colobus and Blue Monkeys",
      "Support the local Kakamega Forest Keepers conservation group"
    ],
    wellnessFocus: "Shinrin-yoku (forest bathing) to reduce cortisol, digital detox session, and guided breathing exercises near the Isiukhu waterfalls.",
    conservationImpact: "20% of tour proceeds fund indigenous tree seedlings planted by our community. This tour directly employs 4 local community guides.",
    itinerary: [
      { day: 1, title: "Departure & Canopy Trek", description: "Depart Kisumu at 5:30 AM. Arrive in Kakamega by 7:15 AM. Enjoy a forest-edge briefing with warm ginger tea. Embark on the 8km Canopy Trek. Midday mindfulness meditation by the river. Summit Lirhanda Hill, descend for a traditional organic lunch hosted by the local women's cooperative, and head back to Kisumu by 6:00 PM." }
    ],
    included: [
      "Roundtrip shared transport from Kisumu",
      "Park entrance fees and conservation levies",
      "Expert community guiding",
      "Traditional organic buffet lunch",
      "Snack pack & mineral water bottle"
    ],
    notIncluded: [
      "Personal travel insurance",
      "Tips for guides and driver",
      "Personal gear"
    ],
    gearList: [
      "Comfortable hiking boots or sturdy sneakers",
      "Rain poncho (highly recommended - rainforest climate)",
      "Insect repellent",
      "Reusable water bottle (at least 1.5L)",
      "Binoculars for bird watching"
    ]
  },
  {
    id: "rusinga-mfangano-escape",
    title: "Rusinga & Mfangano Sacred Island Escape",
    tagline: "Sail to quiet shores, prehistoric art, and slow island life.",
    type: ActivityType.IslandEscape,
    difficulty: DifficultyLevel.Easy,
    duration: "3 Days / 2 Nights",
    location: "Lake Victoria (Rusinga & Mfangano Islands)",
    priceKES: 18500,
    priceUSD: 145,
    image: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1200&q=80",
    description: "Unplug completely on the tranquil shores of Lake Victoria. This wellness-centered escape blends boat excursions, soft trekking to the prehistoric Mawanga Rock Art caves, swimming in the warm waters, and deep-dive community interactions with the Abasuba culture.",
    highlights: [
      "Visit the sacred Mawanga caves containing ancient rock paintings",
      "Sunset boat cruise on Lake Victoria with local fishermen storytelling",
      "Lakeside morning yoga and sound meditation sessions",
      "Stay in eco-cottages committed to zero plastic waste"
    ],
    wellnessFocus: "Gentle restorative yoga on the shoreline, bonfire community circles addressing emotional wellness, and a complete 72-hour social media sabbatical option.",
    conservationImpact: "Supports the Mawanga Cave Preservation Fund and funds organic composting workshops for Rusinga Island farmers.",
    itinerary: [
      { day: 1, title: "Kisumu to Rusinga Island", description: "Morning drive through the scenic Homa Bay county. Board a private boat to Rusinga Island. Settle into our lakeside eco-camp. Sunset meditation followed by a welcome dinner." },
      { day: 2, title: "Mfangano Island & Prehistoric Art", description: "Take a boat to Mfangano Island. Trek up to Mawanga Cave to witness 1,000-year-old rock art. Connect with Abasuba elders. Evening campfire and community drumming." },
      { day: 3, title: "Birding & Return Journey", description: "Sunrise yoga session. Mindful birdwatching of giant kingfishers and fish eagles. Return boat ride to the mainland and drive back to Kisumu, arriving by 5:00 PM." }
    ],
    included: [
      "All ground and water transport from Kisumu",
      "2 nights full-board lakeside eco-accommodation",
      "Community entry and cave preservation fees",
      "Daily guided yoga and meditation",
      "All organic meals & refreshments"
    ],
    notIncluded: [
      "Alcoholic beverages",
      "Personal laundry and tips"
    ],
    gearList: [
      "Light, breathable cotton clothing",
      "Swimwear",
      "Sun protection (hat, sunscreen, sunglasses)",
      "Sandals & light trainers",
      "Personal notebook or journal"
    ]
  },
  {
    id: "nandi-cycling",
    title: "Nandi Hills Escarpment Cycling",
    tagline: "Pedal through mist-kissed highlands and tea estates.",
    type: ActivityType.Cycling,
    difficulty: DifficultyLevel.Hard,
    duration: "1 Day (9 hours)",
    location: "Nandi Hills & Escarpment",
    priceKES: 6000,
    priceUSD: 48,
    image: "https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&w=1200&q=80",
    description: "An exhilarating physical and mental endurance ride. Starting in the crisp, high-altitude air of the Nandi Hills tea estates, we descend 1,200 meters through winding tarmac and gravel trails down into the Kibos valley near Kisumu. It is a thrilling challenge designed to test your limits and build deep social camaraderie.",
    highlights: [
      "Ride through gorgeous, endless rolling green tea plantations",
      "1,200m elevation drop with sweeping Rift Valley views",
      "Fully supported with a follow-me safety vehicle and bike mechanic",
      "Tour an organic local tea factory with tasting session"
    ],
    wellnessFocus: "Mental resilience workshop prior to the descent, post-ride herbal compress, and guided muscle stretching routines.",
    conservationImpact: "Promotes carbon-neutral adventure travel and directly funds cycle-to-school maintenance schemes for local high schoolers.",
    itinerary: [
      { day: 1, title: "Highland Ride & Rift Descent", description: "Load bikes and depart Kisumu at 6:00 AM. Arrive at Nandi Hills tea resort for a hearty oatmeal breakfast. Stretch and mount. Embark on a 42km scenic ride. Support van provides water and bananas. Finish near the lakeside basin at 2:00 PM for a lakeside celebratory barbecue." }
    ],
    included: [
      "Professional mountain bike hire and helmet",
      "Support truck & mechanical backup",
      "Breakfast & lakeside celebration BBQ",
      "Energy gels, fruits, and hydration",
      "First aid trained cycle leads"
    ],
    notIncluded: [
      "Cycling apparel / padded shorts",
      "Personal water bottle cage"
    ],
    gearList: [
      "Padded cycling shorts (highly recommended)",
      "Activewear / sweat-wicking t-shirt",
      "Refillable hydration pack or 2 bottles",
      "Windbreaker jacket (chilly morning highlands)",
      "Sturdy closed shoes"
    ]
  },
  {
    id: "got-ramogi-trek",
    title: "Got Ramogi Sacred Hill Trek",
    tagline: "Journey to the ancestral home of the Luo people.",
    type: ActivityType.Hike,
    difficulty: DifficultyLevel.Moderate,
    duration: "1 Day (10 hours)",
    location: "Got Ramogi Forest, Yimbo",
    priceKES: 3800,
    priceUSD: 30,
    image: "https://images.unsplash.com/photo-1501555088652-021faa106b9b?auto=format&fit=crop&w=1200&q=80",
    description: "Walk in the footsteps of the ancestors. Got Ramogi is a sacred hill covered in pristine indigenous forest, containing historic shrines and sites rich in folklore. This tour combines an eco-trek, traditional storytelling with Luo elders, and an active participation in forest conservation.",
    highlights: [
      "Trek through sacred, untouched dry-land forest habitat",
      "Listen to fireside folklore from the custodians of the hill",
      "Participate in the 'Adopt-a-Tree' initiative by planting a seedling",
      "Stunning views of the Yala Swamp and Lake Kanyaboli"
    ],
    wellnessFocus: "Ancestral grounding exercises, slow contemplative walking in silence, and campfire reflection circles.",
    conservationImpact: "Every trekker plants and names an indigenous sapling. We track and nurture these saplings together with the Yimbo Community Trust.",
    itinerary: [
      { day: 1, title: "Sacred Forest & Heritage", description: "Leave Kisumu at 6:30 AM. Arrive at the foot of Got Ramogi by 8:15 AM. Traditional blessing ceremony with elders. Ascent of the hill (approx. 3.5 hours). Plant seedlings in the restoration zone. Picnic lunch on the peak. Return to Kisumu with a brief stop at Lake Kanyaboli." }
    ],
    included: [
      "Transport, entry fees, and elder guide stipends",
      "Traditional picnic lunch box",
      "Indigenous sapling for the planting ceremony",
      "Ongoing tracking of your planted tree",
      "Snacks and clean drinking water"
    ],
    notIncluded: [
      "Personal gratitude tips for the local community elders"
    ],
    gearList: [
      "Lightweight hiking shoes or trail runners",
      "Suntan lotion & insect repellent",
      "Camera or phone for photography",
      "Wide-brimmed sun hat",
      "Long trousers (to protect from forest brush)"
    ]
  },
  {
    id: "simbi-nyaima-birding",
    title: "Simbi Nyaima Volcanic Lake Tour",
    tagline: "A mystical crater lake rich in birds, legend, and wellness.",
    type: ActivityType.RegionalTrip,
    difficulty: DifficultyLevel.Easy,
    duration: "1 Day (8 hours)",
    location: "Lake Simbi Nyaima, Karachuonyo",
    priceKES: 5500,
    priceUSD: 42,
    image: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1200&q=80",
    description: "Discover Simbi Nyaima, a volcanic crater lake famous for thousands of seasonal flamingos and deeply held local myths of community transformation. Our wellness-oriented trip includes therapeutic lakeside yoga, exploring the hot springs of nearby Homa Hills, and locally caught, organic farm-to-table cuisine.",
    highlights: [
      "Flamingo and waterbird watching with expert spotting scopes",
      "Listen to the vibrant Luo legend of the sunken village of Simbi",
      "Visit the healing thermal pools of the Homa Hills hot springs",
      "Indulge in a sustainable lakeside farm-to-table lunch"
    ],
    wellnessFocus: "Gentle mindfulness yoga on the volcanic caldera edge, breathwork exercises, and foot baths in warm, mineral-rich thermal waters.",
    conservationImpact: "Contributions support the Simbi Wetland Conservation Society, which works to protect the bird nesting habitats and prevent regional siltation.",
    itinerary: [
      { day: 1, title: "Crater Discovery & Spa Experience", description: "Depart Kisumu at 7:00 AM. Travel past the beautiful Kendu Bay. Arrive at Lake Simbi Nyaima. Soft crater-rim walk and morning bird spotting. Outdoor yoga and breathwork. Travel to Homa Hills hot springs for natural mineral therapy. Organic lunch by the lake, and arrive back in Kisumu by 4:00 PM." }
    ],
    included: [
      "Comfortable tour transport",
      "Local conservation guides and spotting scopes",
      "Healthy lakeside lunch & freshly squeezed local juices",
      "Mineral hot spring entry fee",
      "Yoga mat rental"
    ],
    notIncluded: [
      "Personal towels for thermal springs",
      "Personal tips"
    ],
    gearList: [
      "Comfortable slip-on shoes or sandals",
      "Light towel",
      "Sun hat & sunglasses",
      "Comfortable activewear for yoga",
      "Camera with optical zoom"
    ]
  }
];

export const TESTIMONIALS_DATA: Review[] = [
  {
    id: "rev-1",
    tourId: "kakamega-forest",
    author: "Grace Atieno",
    rating: 5,
    date: "2026-06-14",
    comment: "The Kakamega Canopy Hike was exactly what my soul needed! I have been so burnt out with my desk job in Kisumu. Reconnecting with nature, walking in silence, and the beautiful view from Lirhanda Hill was refreshing. The local guides knew every single tree and bird call!",
    location: "Kisumu, Kenya",
    verified: true,
    likes: 24
  },
  {
    id: "rev-2",
    tourId: "rusinga-mfangano-escape",
    author: "David Mwangi",
    rating: 5,
    date: "2026-05-22",
    comment: "An absolute masterpiece of a trip. Staying in eco-lodges right on the water, turning off our phones, and meditating as the sun set over Lake Victoria was unforgettable. Going to the Mawanga Caves felt like traveling through time. Lakeside Adventures makes travel purposeful.",
    location: "Nairobi, Kenya",
    verified: true,
    likes: 18
  },
  {
    id: "rev-3",
    tourId: "nandi-cycling",
    author: "Sarah Jenkins",
    rating: 4,
    date: "2026-07-02",
    comment: "The Nandi Hills cycle was intense but incredibly satisfying. Descending into the valley was exhilarating! The safety truck was right behind us with bananas and ice-cold water, which saved me during the last steep climb. Excellent safety standards and absolute community spirit.",
    location: "Bristol, UK",
    verified: true,
    likes: 12
  }
];

export const FAQS_DATA: FAQ[] = [
  {
    id: "faq-1",
    category: "Logistics",
    question: "Where do your tours start from and what are the departure times?",
    answer: "All our standard tours depart from the Lakeside Adventure Community Hub located near the Kisumu Impala Sanctuary gate. Departure times range from 5:30 AM to 7:00 AM depending on the distance of the destination. We send out precise pickup details, coordinates, and driver contacts 24 hours before your trip."
  },
  {
    id: "faq-2",
    category: "Logistics",
    question: "What is your cancellation and rescheduling policy?",
    answer: "We understand that plans change. You can cancel your trip up to 48 hours before departure for a full 100% refund or free reschedule. Cancellations within 24 to 48 hours receive a 50% refund. Cancellations under 24 hours are non-refundable, but we will gladly try to transfer your spot to a friend or family member if you notify us."
  },
  {
    id: "faq-3",
    category: "Gear",
    question: "Do I need to own professional hiking or cycling gear?",
    answer: "No, you don't! For our hiking treks, standard athletic shoes with good grip and comfortable clothes are completely sufficient. For our cycling tours, we provide a fleet of high-quality, serviced mountain bikes and safety helmets included in the tour price. If you have any special requirements, let us know during booking."
  },
  {
    id: "faq-4",
    category: "Wellness",
    question: "What does 'Wellness-Focused Travel' actually mean?",
    answer: "It means we don't just rush from one sight to another. We build time into our itineraries for digital disconnects, guided breathwork, shoreline yoga, and campfire sharing circles. We design our adventures to support mental well-being, reduce stress, and cultivate lasting human connection."
  },
  {
    id: "faq-5",
    category: "Impact",
    question: "How does my booking support the local East African communities?",
    answer: "We employ exclusively local indigenous guides, pay fair living wages that are 30% above the industry average, and source all our meals from local women-led farming cooperatives. Additionally, 20% of all profits go towards conservation efforts, like buying indigenous tree seedlings and school supplies for community youth."
  },
  {
    id: "faq-6",
    category: "Booking",
    question: "Can I pay using M-Pesa or standard credit cards?",
    answer: "Yes! We accept M-Pesa (Buy Goods Till Number or Express request directly to your phone) and all major credit/debit cards (Visa, Mastercard, Amex). The booking checkout on our website simulates both flows securely."
  }
];

export const INITIAL_STATS: ImpactStats = {
  treesPlanted: 1420,
  wasteCollectedKG: 680,
  guidesSupported: 14,
  communityScholars: 8
};
