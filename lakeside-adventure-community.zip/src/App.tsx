import React, { useState, useEffect } from "react";
import {
  Compass,
  MapPin,
  Clock,
  Heart,
  ChevronRight,
  ShieldCheck,
  Leaf,
  Users,
  Search,
  SlidersHorizontal,
  Plus,
  Minus,
  Check,
  X,
  CreditCard,
  Phone,
  HelpCircle,
  TrendingUp,
  Award,
  Sparkles,
  Calendar,
  MessageSquare,
  Bookmark,
  ChevronDown,
  Info
} from "lucide-react";
import Navbar from "./components/Navbar";
import AdventureCalendar from "./components/AdventureCalendar";
import { TOURS_DATA, TESTIMONIALS_DATA, FAQS_DATA, INITIAL_STATS } from "./data/tours";
import { Tour, Booking, ActivityType, DifficultyLevel, Review, FAQ, ImpactStats } from "./types";

export default function App() {
  const [activeSection, setActiveSection] = useState<string>("explore");
  
  // App state
  const [tours, setTours] = useState<Tour[]>(TOURS_DATA);
  const [selectedTour, setSelectedTour] = useState<Tour | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [testimonials, setTestimonials] = useState<Review[]>(TESTIMONIALS_DATA);
  const [faqs, setFaqs] = useState<FAQ[]>(FAQS_DATA);
  const [stats, setStats] = useState<ImpactStats>(INITIAL_STATS);

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState<string>("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");

  // Booking Modal / Checkout state
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [bookingTourId, setBookingTourId] = useState<string>("");
  const [bookingDate, setBookingDate] = useState("");
  const [bookingGuests, setBookingGuests] = useState(1);
  const [bookingName, setBookingName] = useState("");
  const [bookingEmail, setBookingEmail] = useState("");
  const [bookingPhone, setBookingPhone] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"MPESA" | "CARD">("MPESA");
  const [mpesaPhone, setMpesaPhone] = useState("");
  const [specialRequests, setSpecialRequests] = useState("");
  const [paymentStep, setPaymentStep] = useState<"form" | "processing" | "pin_wait" | "success">("form");

  // Interactive packlist state
  const [packedItems, setPackedItems] = useState<{ [key: string]: boolean }>({});

  // Guide message state
  const [guideName, setGuideName] = useState("Aron");
  const [guideMessage, setGuideMessage] = useState("");
  const [guideMessageSubmitted, setGuideMessageSubmitted] = useState(false);

  // Testimonial likes state
  const [likedReviews, setLikedReviews] = useState<{ [key: string]: boolean }>({});

  // FAQ Expanded Categories
  const [activeFaqCategory, setActiveFaqCategory] = useState<string>("All");
  const [expandedFaqId, setExpandedFaqId] = useState<string | null>(null);

  // Sync Booking form's tour option if selectedTour changes
  useEffect(() => {
    if (selectedTour) {
      setBookingTourId(selectedTour.id);
    } else if (TOURS_DATA.length > 0 && !bookingTourId) {
      setBookingTourId(TOURS_DATA[0].id);
    }
  }, [selectedTour]);

  // Handle Search and Filter
  const filteredTours = tours.filter((tour) => {
    const matchesSearch =
      tour.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tour.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tour.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesType = selectedType === "all" || tour.type === selectedType;
    const matchesDifficulty = selectedDifficulty === "all" || tour.difficulty === selectedDifficulty;

    return matchesSearch && matchesType && matchesDifficulty;
  });

  // Calculate current booking's total cost
  const selectedBookingTour = tours.find(t => t.id === bookingTourId) || tours[0];
  const currentTotalKES = selectedBookingTour ? selectedBookingTour.priceKES * bookingGuests : 0;

  // Open booking modal
  const handleOpenBooking = (tourId?: string) => {
    if (tourId) {
      setBookingTourId(tourId);
    } else if (selectedTour) {
      setBookingTourId(selectedTour.id);
    } else {
      setBookingTourId(tours[0]?.id || "");
    }
    
    // Set a default date 1 week in future
    const defaultDate = new Date();
    defaultDate.setDate(defaultDate.getDate() + 7);
    setBookingDate(defaultDate.toISOString().split("T")[0]);
    
    setBookingGuests(1);
    setPaymentStep("form");
    setBookingModalOpen(true);
  };

  // Submit Simulated Payment
  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingTourId || !bookingDate || !bookingName || !bookingEmail || !bookingPhone) {
      alert("Please fill in all required passenger fields.");
      return;
    }

    setPaymentStep("processing");

    // MPESA flow simulation
    if (paymentMethod === "MPESA") {
      setTimeout(() => {
        setPaymentStep("pin_wait");
        setTimeout(() => {
          completeBooking();
        }, 3000); // Simulate waiting for M-Pesa pin entry
      }, 2000); // Simulate prompt trigger
    } else {
      // Card payment flow simulation
      setTimeout(() => {
        completeBooking();
      }, 3000);
    }
  };

  const completeBooking = () => {
    const newBooking: Booking = {
      id: "BK-" + Math.floor(100000 + Math.random() * 900000),
      tourId: bookingTourId,
      tourTitle: selectedBookingTour.title,
      tourImage: selectedBookingTour.image,
      tourType: selectedBookingTour.type,
      priceKES: selectedBookingTour.priceKES,
      date: bookingDate,
      guests: bookingGuests,
      fullName: bookingName,
      email: bookingEmail,
      phone: bookingPhone,
      paymentMethod,
      mpesaNumber: paymentMethod === "MPESA" ? mpesaPhone : undefined,
      specialRequests,
      totalCostKES: currentTotalKES,
      bookingDate: new Date().toLocaleDateString(),
      status: "CONFIRMED"
    };

    setBookings([newBooking, ...bookings]);
    
    // Boost eco stats dynamically on booking to show simulated impact!
    setStats(prev => ({
      ...prev,
      treesPlanted: prev.treesPlanted + (bookingGuests * 3),
      wasteCollectedKG: prev.wasteCollectedKG + (bookingGuests * 5),
      guidesSupported: prev.guidesSupported + 1
    }));

    setPaymentStep("success");
  };

  // Close booking modal and head to passenger dashboard
  const handleFinishBookingFlow = () => {
    setBookingModalOpen(false);
    setActiveSection("my-bookings");
  };

  // Toggle checklist item
  const togglePackItem = (key: string) => {
    setPackedItems(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // Like a review
  const handleLikeReview = (reviewId: string) => {
    if (likedReviews[reviewId]) return; // limit to 1 like
    setLikedReviews(prev => ({ ...prev, [reviewId]: true }));
    setTestimonials(prev =>
      prev.map(r => r.id === reviewId ? { ...r, likes: r.likes + 1 } : r)
    );
  };

  // Submit encouragement message for guides
  const handleSendGuideMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guideMessage.trim()) return;
    setGuideMessageSubmitted(true);
    setTimeout(() => {
      setGuideMessage("");
      setGuideMessageSubmitted(false);
      alert(`Message safely routed to ${guideName}! Thank you for supporting our community guides.`);
    }, 2000);
  };

  // Highlight reviews belonging to selected tour
  const relevantReviews = selectedTour
    ? testimonials.filter(r => r.tourId === selectedTour.id)
    : testimonials;

  return (
    <div id="app-root" className="min-h-screen bg-[#FDFBF7] text-[#0B2545] font-sans antialiased flex flex-col">
      {/* Dynamic Navbar with active section mapping */}
      <Navbar
        onNavigate={(section) => {
          setActiveSection(section);
          window.scrollTo({ top: 0, behavior: "smooth" });
        }}
        activeSection={activeSection}
        onOpenBooking={() => handleOpenBooking()}
        bookingCount={bookings.length}
      />

      {/* Main Container */}
      <main className="flex-grow">
        {/* ADVENTURE CALENDAR TAB */}
        {activeSection === "calendar" && (
          <AdventureCalendar
            tours={tours}
            onSelectTour={(tour) => {
              setSelectedTour(tour);
            }}
            onOpenBooking={(tourId) => {
              handleOpenBooking(tourId);
            }}
          />
        )}

        {/* EXPLORE ADVENTURES TAB */}
        {activeSection === "explore" && (
          <div id="explore-section" className="animate-fadeIn">
            {/* Immersive Lake Victoria Sunset Hero Banner */}
            <div className="relative overflow-hidden bg-[#0B2545] text-white">
              {/* Sunset Decorative Backdrop */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B2545] via-[#0B2545]/70 to-transparent z-10" />
              <div 
                className="absolute inset-0 bg-cover bg-center opacity-45 mix-blend-overlay scale-105 transform transition-transform duration-1000"
                style={{ backgroundImage: `url('https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1920&q=80')` }}
              />
              
              {/* Floating sun/gradient decorative circle representing the logo's sky */}
              <div className="absolute top-10 right-10 w-96 h-96 rounded-full bg-gradient-to-br from-[#C94A29]/40 via-[#F4A261]/20 to-transparent blur-3xl" />

              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-28 relative z-20">
                <div className="max-w-3xl">
                  {/* Small Brand Badge */}
                  <span className="inline-flex items-center space-x-2 bg-[#E76F51]/20 border border-[#E76F51]/30 text-[#F4A261] px-4 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase mb-6 backdrop-blur-xs">
                    <Sparkles className="w-3.5 h-3.5 text-[#E76F51]" />
                    <span>Explore • Connect • Remember</span>
                  </span>
                  
                  {/* Majestic Scannable Headline */}
                  <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight mb-6">
                    Nature is the ultimate <br />
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#F4A261] via-[#E76F51] to-[#E9C46A]">
                      wellness sanctuary.
                    </span>
                  </h1>
                  
                  <p className="text-lg sm:text-xl text-amber-50/80 mb-10 leading-relaxed font-normal">
                    We are a Kisumu-based eco-adventure initiative bringing people together through slow hiking, cycling trails, and island retreats across East Africa. Join us to nurture mental well-being and fuel environmental impact.
                  </p>

                  {/* Trust CTA Pair */}
                  <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                    <button
                      id="hero-book-now"
                      onClick={() => handleOpenBooking()}
                      className="bg-[#E76F51] hover:bg-[#C94A29] text-white px-8 py-4 rounded-xl font-bold tracking-wide shadow-lg shadow-orange-500/10 hover:shadow-orange-500/25 transition-all text-center cursor-pointer flex items-center justify-center space-x-2"
                    >
                      <Calendar className="w-5 h-5" />
                      <span>Book Your Next Tour</span>
                    </button>
                    <a
                      href="#adventure-list"
                      className="bg-white/10 hover:bg-white/15 border border-white/20 text-white px-8 py-4 rounded-xl font-bold tracking-wide transition-all text-center backdrop-blur-xs flex items-center justify-center space-x-2 cursor-pointer"
                    >
                      <span>Explore Adventures</span>
                      <ChevronRight className="w-4 h-4" />
                    </a>
                  </div>

                  {/* Micro-Trust Highlights */}
                  <div className="grid grid-cols-3 gap-6 mt-12 pt-10 border-t border-white/10 text-white/80">
                    <div>
                      <span className="block text-2xl font-black text-[#F4A261]">100%</span>
                      <span className="text-xs text-amber-50/60 uppercase tracking-wider font-semibold">Local Guides</span>
                    </div>
                    <div>
                      <span className="block text-2xl font-black text-[#F4A261]">20%</span>
                      <span className="text-xs text-amber-50/60 uppercase tracking-wider font-semibold">Eco-Impact Fund</span>
                    </div>
                    <div>
                      <span className="block text-2xl font-black text-[#F4A261]">4.9★</span>
                      <span className="text-xs text-amber-50/60 uppercase tracking-wider font-semibold">Traveler Rating</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Angle wave bottom layout to connect naturally with sandy background */}
              <div className="absolute bottom-0 left-0 right-0 h-8 bg-[#FDFBF7] clip-bottom-wave" />
            </div>

            {/* Live Eco-Impact Meter (Directly addresses the impact philosophy) */}
            <section id="impact-bar" className="bg-[#0B2545] text-white py-8 border-t border-b border-white/5 relative z-20 shadow-inner">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-6 lg:space-y-0">
                  <div className="flex items-center space-x-4">
                    <div className="bg-[#E76F51]/20 p-3 rounded-xl border border-[#E76F51]/30">
                      <Leaf className="w-6 h-6 text-[#F4A261]" />
                    </div>
                    <div>
                      <h4 className="font-bold text-lg tracking-tight">Our Shared Footprint</h4>
                      <p className="text-xs text-amber-50/60 font-medium">Every adventure funds actual, verified environmental projects in Kisumu and Nandi.</p>
                    </div>
                  </div>

                  {/* Interactive Stats Counters */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-12 flex-grow max-w-4xl lg:ml-12">
                    <div className="bg-white/5 p-4 rounded-xl border border-white/5 text-center">
                      <span className="block text-3xl font-black text-[#F4A261]">{stats.treesPlanted}</span>
                      <span className="text-[10px] uppercase font-bold text-amber-50/60 tracking-wider">Indigenous Trees Planted</span>
                    </div>
                    <div className="bg-white/5 p-4 rounded-xl border border-white/5 text-center">
                      <span className="block text-3xl font-black text-[#F4A261]">{stats.wasteCollectedKG} kg</span>
                      <span className="text-[10px] uppercase font-bold text-amber-50/60 tracking-wider">Lakeside Litter Salvaged</span>
                    </div>
                    <div className="bg-white/5 p-4 rounded-xl border border-white/5 text-center">
                      <span className="block text-3xl font-black text-[#F4A261]">{stats.guidesSupported}</span>
                      <span className="text-[10px] uppercase font-bold text-amber-50/60 tracking-wider">Local Guides Sustained</span>
                    </div>
                    <div className="bg-white/5 p-4 rounded-xl border border-white/5 text-center">
                      <span className="block text-3xl font-black text-[#F4A261]">{stats.communityScholars}</span>
                      <span className="text-[10px] uppercase font-bold text-amber-50/60 tracking-wider">Local Scholars Co-funded</span>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Adventure Catalog & Search Engine */}
            <section id="adventure-list" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
              <div className="text-center max-w-2xl mx-auto mb-16">
                <span className="font-mono text-xs font-bold text-[#E76F51] uppercase tracking-[0.2em]">Eco-Wellness Catalogue</span>
                <h2 className="text-3xl sm:text-4xl font-black text-[#0B2545] mt-3 tracking-tight">Select Your Sanctuary</h2>
                <p className="text-gray-600 mt-4 leading-relaxed">
                  We schedule curated, small-group adventures designed to restore peace, foster relationships, and fund real local community development. Find yours.
                </p>
              </div>

              {/* Dynamic Filter Controls */}
              <div id="filter-panel" className="bg-white p-6 rounded-2xl border border-gray-100 shadow-md shadow-gray-100/50 mb-10">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  {/* Search Bar */}
                  <div className="relative flex-grow max-w-md">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      id="tour-search-input"
                      type="text"
                      placeholder="Search forest hikes, island escapes..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 focus:border-[#E76F51] focus:ring-1 focus:ring-[#E76F51] rounded-xl pl-12 pr-4 py-3.5 text-sm text-gray-800 outline-hidden transition-all placeholder-gray-400 font-medium"
                    />
                  </div>

                  {/* Filter Selects */}
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="flex items-center space-x-2 bg-gray-50 px-3.5 py-1.5 rounded-lg text-xs font-bold text-gray-500 uppercase tracking-wider">
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                      <span>Filter By:</span>
                    </div>
                    
                    {/* Activity Type Selector */}
                    <select
                      id="filter-activity-type"
                      value={selectedType}
                      onChange={(e) => setSelectedType(e.target.value)}
                      className="bg-white border border-gray-200 focus:border-[#E76F51] rounded-xl px-4 py-2.5 text-sm font-semibold text-gray-700 cursor-pointer outline-hidden transition-all shadow-xs"
                    >
                      <option value="all">All Activities</option>
                      <option value={ActivityType.Hike}>🥾 Hikes</option>
                      <option value={ActivityType.Cycling}>🚴 Cycling Adventures</option>
                      <option value={ActivityType.IslandEscape}>🏝️ Island Escapes</option>
                      <option value={ActivityType.RegionalTrip}>🗺️ Regional Trips</option>
                    </select>

                    {/* Difficulty Selector */}
                    <select
                      id="filter-difficulty"
                      value={selectedDifficulty}
                      onChange={(e) => setSelectedDifficulty(e.target.value)}
                      className="bg-white border border-gray-200 focus:border-[#E76F51] rounded-xl px-4 py-2.5 text-sm font-semibold text-gray-700 cursor-pointer outline-hidden transition-all shadow-xs"
                    >
                      <option value="all">All Difficulties</option>
                      <option value={DifficultyLevel.Easy}>Easy (Relaxed)</option>
                      <option value={DifficultyLevel.Moderate}>Moderate (Active)</option>
                      <option value={DifficultyLevel.Hard}>Hard (Challenging)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Catalog Grid */}
              {filteredTours.length === 0 ? (
                <div id="no-tours-found" className="text-center py-20 bg-white rounded-2xl border border-dashed border-gray-200">
                  <Compass className="w-12 h-12 text-[#E76F51] mx-auto opacity-40 mb-4 animate-pulse" />
                  <h3 className="text-xl font-bold text-[#0B2545]">No Matching Sanctuary Found</h3>
                  <p className="text-gray-500 mt-2 text-sm">Try widening your search or adjusting your filters!</p>
                  <button
                    onClick={() => {
                      setSearchQuery("");
                      setSelectedType("all");
                      setSelectedDifficulty("all");
                    }}
                    className="mt-6 bg-[#0B2545] text-white px-6 py-2.5 rounded-xl text-sm font-bold cursor-pointer"
                  >
                    Clear All Filters
                  </button>
                </div>
              ) : (
                <div id="tours-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {filteredTours.map((tour) => {
                    const diffColors =
                      tour.difficulty === DifficultyLevel.Easy
                        ? "bg-green-50 text-green-700 border-green-100"
                        : tour.difficulty === DifficultyLevel.Moderate
                        ? "bg-orange-50 text-[#E76F51] border-orange-100"
                        : "bg-red-50 text-red-700 border-red-100";

                    return (
                      <article
                        key={tour.id}
                        id={`tour-card-${tour.id}`}
                        className="bg-white rounded-3xl border border-gray-100 overflow-hidden shadow-md shadow-gray-100/50 hover:shadow-xl hover:shadow-gray-100/80 transition-all duration-300 flex flex-col group"
                      >
                        {/* Tour Image */}
                        <div className="relative h-64 overflow-hidden bg-gray-100">
                          <img
                            src={tour.image}
                            alt={tour.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                          
                          {/* Badges Overlay */}
                          <div className="absolute top-4 left-4 flex flex-col space-y-2 z-10">
                            <span className="bg-white/95 backdrop-blur-xs text-[#0B2545] px-3.5 py-1.5 rounded-xl text-xs font-bold shadow-sm">
                              {tour.type}
                            </span>
                            <span className={`px-3.5 py-1.5 rounded-xl text-xs font-bold border shadow-sm ${diffColors}`}>
                              {tour.difficulty}
                            </span>
                          </div>

                          {/* Quick Specs Overlay */}
                          <div className="absolute bottom-4 left-4 right-4 bg-[#0B2545]/90 backdrop-blur-md px-4 py-3 rounded-2xl text-white flex justify-between text-xs z-10 border border-white/10 shadow-lg">
                            <span className="flex items-center space-x-1 font-semibold">
                              <Clock className="w-3.5 h-3.5 text-[#F4A261]" />
                              <span>{tour.duration}</span>
                            </span>
                            <span className="flex items-center space-x-1 font-semibold">
                              <MapPin className="w-3.5 h-3.5 text-[#F4A261]" />
                              <span className="truncate max-w-[120px]">{tour.location}</span>
                            </span>
                          </div>
                        </div>

                        {/* Card Body */}
                        <div className="p-6 flex-grow flex flex-col">
                          <h3 className="text-xl font-bold text-[#0B2545] leading-tight hover:text-[#E76F51] transition-colors">
                            {tour.title}
                          </h3>
                          <p className="text-xs text-gray-400 mt-1 font-medium italic">{tour.tagline}</p>
                          
                          <p className="text-sm text-gray-600 mt-4 line-clamp-3 leading-relaxed">
                            {tour.description}
                          </p>

                          {/* Eco-wellness snippet */}
                          <div className="mt-5 pt-4 border-t border-gray-50 flex items-start space-x-2.5">
                            <Heart className="w-4 h-4 text-[#E76F51] shrink-0 mt-0.5" />
                            <div className="text-xs">
                              <span className="font-bold text-[#0B2545] block">Mindfulness Focus:</span>
                              <p className="text-gray-500 line-clamp-1 italic mt-0.5">{tour.wellnessFocus}</p>
                            </div>
                          </div>

                          {/* Eco contribution snippet */}
                          <div className="mt-3 pt-3 border-t border-gray-50 flex items-start space-x-2.5">
                            <Leaf className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                            <div className="text-xs">
                              <span className="font-bold text-emerald-800 block">Eco-Action:</span>
                              <p className="text-gray-500 line-clamp-1 italic mt-0.5">{tour.conservationImpact}</p>
                            </div>
                          </div>

                          {/* Price & CTA Section */}
                          <div className="mt-8 pt-5 border-t border-gray-100 flex items-center justify-between">
                            <div>
                              <span className="text-[10px] text-gray-400 uppercase tracking-wider font-bold block">From</span>
                              <div className="flex items-baseline space-x-1">
                                <span className="text-2xl font-black text-[#0B2545]">KES {tour.priceKES.toLocaleString()}</span>
                                <span className="text-xs font-semibold text-gray-400">/ ~${tour.priceUSD}</span>
                              </div>
                            </div>

                            <div className="flex space-x-2">
                              <button
                                id={`view-details-btn-${tour.id}`}
                                onClick={() => {
                                  setSelectedTour(tour);
                                  window.scrollTo({ top: 0, behavior: "smooth" });
                                }}
                                className="bg-gray-100 hover:bg-gray-200 text-[#0B2545] p-3.5 rounded-xl transition-all cursor-pointer shadow-xs"
                                title="View details"
                              >
                                <Info className="w-5 h-5" />
                              </button>
                              <button
                                id={`book-now-btn-${tour.id}`}
                                onClick={() => handleOpenBooking(tour.id)}
                                className="bg-[#E76F51] hover:bg-[#C94A29] text-white px-5 py-3.5 rounded-xl text-xs font-bold tracking-wider uppercase transition-all cursor-pointer shadow-md shadow-orange-500/10"
                              >
                                Book Spot
                              </button>
                            </div>
                          </div>
                        </div>
                      </article>
                    );
                  })}
                </div>
              )}
            </section>
            
            {/* GOOGLE REVIEWS & TESTIMONIALS COMPONENT */}
            <section id="google-reviews-section" className="bg-amber-50/20 border-t border-b border-gray-100 py-20 relative overflow-hidden">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-[#F4A261]/10 to-transparent blur-3xl rounded-full" />
              
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                  
                  {/* Google Reviews rating & CTA box */}
                  <div className="lg:col-span-5 space-y-6">
                    <span className="font-mono text-xs font-bold text-[#E76F51] uppercase tracking-[0.2em] flex items-center gap-1.5">
                      <Award className="w-4 h-4" />
                      <span>Certified Satisfaction</span>
                    </span>
                    <h2 className="text-3xl sm:text-4xl font-black text-[#0B2545] tracking-tight">
                      What our adventurers say on Google
                    </h2>
                    <p className="text-gray-600 text-sm sm:text-base leading-relaxed">
                      We believe in absolute transparency and community empowerment. Check out our verified guest reviews on Google, or leave us your feedback on how our slow-hiking, island retreats, and local guides helped restore your peace of mind.
                    </p>
                    
                    {/* Trust indicators */}
                    <div className="flex items-center space-x-6 py-2 border-t border-b border-gray-150/50">
                      <div>
                        <span className="text-3xl font-black text-[#0B2545]">4.9★</span>
                        <span className="text-[10px] uppercase font-bold text-gray-400 block mt-0.5 tracking-wider">Overall Rating</span>
                      </div>
                      <div className="border-l border-gray-200 pl-6">
                        <span className="text-3xl font-black text-[#0B2545]">180+</span>
                        <span className="text-[10px] uppercase font-bold text-gray-400 block mt-0.5 tracking-wider">Happy Travelers</span>
                      </div>
                      <div className="border-l border-gray-200 pl-6">
                        <span className="text-3xl font-black text-[#E76F51]">100%</span>
                        <span className="text-[10px] uppercase font-bold text-gray-400 block mt-0.5 tracking-wider">Verified Reviews</span>
                      </div>
                    </div>

                    {/* Prominent link to Google reviews */}
                    <a
                      href="https://share.google/e4LG0nHHn4TwAVXR3"
                      target="_blank"
                      rel="noopener noreferrer"
                      id="google-reviews-external-cta"
                      className="inline-flex items-center space-x-2.5 bg-[#0B2545] hover:bg-slate-800 text-white font-bold text-sm px-6 py-4 rounded-xl shadow-lg transition-all cursor-pointer"
                    >
                      <span>Read Our Live Google Reviews</span>
                      <ChevronRight className="w-4 h-4 text-[#F4A261]" />
                    </a>
                  </div>

                  {/* Testimonial slider / showcase cards */}
                  <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {testimonials.map((review) => (
                      <div
                        key={review.id}
                        className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm shadow-gray-100/50 flex flex-col justify-between hover:shadow-md transition-shadow"
                      >
                        <div className="space-y-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-bold text-sm text-[#0B2545]">{review.author}</h4>
                              <span className="text-[10px] text-gray-400 block">{review.location} • {review.date}</span>
                            </div>
                            <span className="text-amber-400 text-xs font-bold shrink-0">{"★".repeat(review.rating)}</span>
                          </div>
                          
                          <p className="text-xs text-gray-600 leading-relaxed italic">
                            "{review.comment}"
                          </p>
                        </div>

                        <div className="mt-6 pt-4 border-t border-gray-50 flex items-center justify-between text-[10px]">
                          <span className="bg-emerald-50 text-emerald-800 px-2 py-1 rounded-md font-bold uppercase">
                            Verified Guest
                          </span>
                          <button
                            onClick={() => handleLikeReview(review.id)}
                            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-all cursor-pointer ${
                              likedReviews[review.id]
                                ? "bg-[#E76F51]/10 text-[#E76F51] font-bold"
                                : "bg-gray-50 hover:bg-gray-100 text-gray-400"
                            }`}
                          >
                            <span>👍 Helpful</span>
                            <span className="font-black">{review.likes}</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                </div>
              </div>
            </section>

            {/* Selected Tour Detailed Overlay (Promise and prep detail) */}
            {selectedTour && (
              <div id="tour-details-modal" className="fixed inset-0 z-50 bg-[#0B2545]/60 backdrop-blur-sm flex items-center justify-end animate-fadeIn">
                <div className="bg-[#FDFBF7] w-full max-w-4xl h-full overflow-y-auto shadow-2xl flex flex-col relative animate-slideLeft">
                  {/* Close button */}
                  <button
                    onClick={() => setSelectedTour(null)}
                    className="absolute top-6 right-6 z-10 bg-white/90 hover:bg-white p-2 rounded-full text-[#0B2545] shadow-lg cursor-pointer hover:scale-110 transition-transform"
                  >
                    <X className="w-5 h-5" />
                  </button>

                  {/* Header Banner */}
                  <div className="relative h-96 bg-[#0B2545]">
                    <img
                      src={selectedTour.image}
                      alt={selectedTour.title}
                      className="w-full h-full object-cover opacity-60"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#FDFBF7] via-transparent to-[#0B2545]/40" />
                    
                    <div className="absolute bottom-6 left-8 right-8 text-white">
                      <span className="bg-[#E76F51] text-white px-4 py-1.5 rounded-full text-xs font-bold tracking-wider uppercase inline-block mb-3 shadow-md">
                        {selectedTour.type} • {selectedTour.difficulty}
                      </span>
                      <h2 className="text-3xl sm:text-4xl font-black text-[#0B2545] drop-shadow-sm tracking-tight">
                        {selectedTour.title}
                      </h2>
                      <p className="text-gray-700 text-sm sm:text-base font-semibold mt-1 italic max-w-2xl">
                        "{selectedTour.tagline}"
                      </p>
                    </div>
                  </div>

                  {/* Modal Body */}
                  <div className="p-8 sm:p-12 space-y-10 flex-grow">
                    {/* Adventure Specifics Bar */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-white p-5 rounded-2xl border border-gray-100 shadow-sm text-center">
                      <div className="border-r border-gray-100 last:border-0 py-2">
                        <span className="text-[10px] text-gray-400 font-bold uppercase block">Duration</span>
                        <span className="text-sm font-extrabold text-[#0B2545]">{selectedTour.duration}</span>
                      </div>
                      <div className="border-r border-gray-100 last:border-0 py-2">
                        <span className="text-[10px] text-gray-400 font-bold uppercase block">Location</span>
                        <span className="text-sm font-extrabold text-[#0B2545] truncate block px-2">{selectedTour.location}</span>
                      </div>
                      <div className="border-r border-gray-100 last:border-0 py-2">
                        <span className="text-[10px] text-gray-400 font-bold uppercase block">Price per guest</span>
                        <span className="text-sm font-extrabold text-[#E76F51]">KES {selectedTour.priceKES.toLocaleString()}</span>
                      </div>
                      <div className="py-2">
                        <span className="text-[10px] text-gray-400 font-bold uppercase block">Flexible Booking</span>
                        <span className="text-sm font-extrabold text-green-600">Free Cancel (48h)</span>
                      </div>
                    </div>

                    {/* Description and Highlights */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                      <div className="lg:col-span-2 space-y-6">
                        <h3 className="text-xl font-bold text-[#0B2545] border-b border-gray-100 pb-3">The Experience</h3>
                        <p className="text-gray-600 leading-relaxed text-base">{selectedTour.description}</p>
                        
                        <div className="bg-[#0B2545]/5 p-6 rounded-2xl border border-[#0B2545]/5 space-y-4">
                          <h4 className="font-bold text-sm text-[#0B2545] flex items-center space-x-2">
                            <Heart className="w-4 h-4 text-[#E76F51]" />
                            <span>Wellness & Mindfulness Integration</span>
                          </h4>
                          <p className="text-xs text-gray-600 leading-relaxed italic">
                            "{selectedTour.wellnessFocus}"
                          </p>
                        </div>

                        <div className="bg-emerald-50/50 p-6 rounded-2xl border border-emerald-100 space-y-4">
                          <h4 className="font-bold text-sm text-emerald-800 flex items-center space-x-2">
                            <Leaf className="w-4 h-4 text-emerald-600" />
                            <span>Environmental & Local Conservation Footprint</span>
                          </h4>
                          <p className="text-xs text-gray-600 leading-relaxed italic">
                            "{selectedTour.conservationImpact}"
                          </p>
                        </div>
                      </div>

                      {/* Highlights checklist */}
                      <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm h-fit">
                        <h4 className="font-bold text-sm uppercase text-[#0B2545] tracking-wider mb-4 border-b border-gray-50 pb-3">
                          Adventure Highlights
                        </h4>
                        <ul className="space-y-3.5">
                          {selectedTour.highlights.map((h, i) => (
                            <li key={i} className="flex items-start space-x-3 text-xs text-gray-600 leading-normal">
                              <span className="bg-[#E76F51]/10 text-[#E76F51] p-1 rounded-md shrink-0">
                                <Check className="w-3 h-3" strokeWidth={3} />
                              </span>
                              <span>{h}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Structured Day-by-Day Itinerary */}
                    <div className="space-y-6 bg-white p-8 rounded-2xl border border-gray-100">
                      <h3 className="text-xl font-bold text-[#0B2545]">Day-by-Day Itinerary</h3>
                      <div className="relative border-l-2 border-gray-100 pl-6 ml-4 space-y-8">
                        {selectedTour.itinerary.map((step, idx) => (
                          <div key={idx} className="relative">
                            {/* Bullet marker */}
                            <span className="absolute -left-10 top-0.5 bg-[#E76F51] text-white font-extrabold text-[10px] w-6 h-6 flex items-center justify-center rounded-full ring-4 ring-[#FDFBF7]">
                              {step.day}
                            </span>
                            <h4 className="font-bold text-base text-[#0B2545]">{step.title}</h4>
                            <p className="text-gray-600 text-sm mt-2 leading-relaxed">{step.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Logistics, What's Included vs Not Included */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="bg-emerald-50/20 p-6 rounded-2xl border border-emerald-100/50">
                        <h4 className="font-bold text-sm text-[#0B2545] uppercase tracking-wider mb-4 flex items-center space-x-2">
                          <span className="bg-emerald-600 text-white w-5 h-5 flex items-center justify-center rounded-full text-xs">✓</span>
                          <span>What is Included</span>
                        </h4>
                        <ul className="space-y-3">
                          {selectedTour.included.map((item, i) => (
                            <li key={i} className="flex items-center space-x-2 text-xs text-gray-600">
                              <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-red-50/10 p-6 rounded-2xl border border-red-100/30">
                        <h4 className="font-bold text-sm text-[#0B2545] uppercase tracking-wider mb-4 flex items-center space-x-2">
                          <span className="bg-red-500 text-white w-5 h-5 flex items-center justify-center rounded-full text-xs">✕</span>
                          <span>What's Not Included</span>
                        </h4>
                        <ul className="space-y-3">
                          {selectedTour.notIncluded.map((item, i) => (
                            <li key={i} className="flex items-center space-x-2 text-xs text-gray-500">
                              <X className="w-3.5 h-3.5 text-red-500 shrink-0" />
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Interactive traveler gear checklist */}
                    <div className="bg-amber-50/30 p-8 rounded-2xl border border-amber-100 space-y-4">
                      <div className="flex items-center space-x-2">
                        <ShieldCheck className="w-5 h-5 text-[#E76F51]" />
                        <h4 className="font-bold text-sm uppercase text-[#0B2545] tracking-wider">
                          Interactive Packing Checklist (What to Bring)
                        </h4>
                      </div>
                      <p className="text-xs text-gray-500">
                        Get ready for your adventure! Cross off items as you place them inside your backpack.
                      </p>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
                        {selectedTour.gearList.map((gear, idx) => {
                          const gearKey = `${selectedTour.id}-${idx}`;
                          const isPacked = packedItems[gearKey];
                          return (
                            <label
                              key={idx}
                              className={`flex items-center space-x-3 p-3.5 rounded-xl border cursor-pointer select-none transition-all ${
                                isPacked
                                  ? "bg-amber-50 border-[#E9C46A] text-gray-400 line-through"
                                  : "bg-white border-gray-100 text-gray-700 hover:border-gray-200"
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={!!isPacked}
                                onChange={() => togglePackItem(gearKey)}
                                className="sr-only"
                              />
                              <span className={`w-5 h-5 rounded-md flex items-center justify-center border transition-all ${
                                isPacked ? "bg-[#E76F51] border-[#E76F51] text-white" : "border-gray-200 bg-white"
                              }`}>
                                {isPacked && <Check className="w-3.5 h-3.5" strokeWidth={3} />}
                              </span>
                              <span className="text-xs font-semibold">{gear}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    {/* Verified Traveler Reviews about this Tour */}
                    <div className="space-y-6">
                      <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                        <h3 className="text-xl font-bold text-[#0B2545]">Verified Reviews ({relevantReviews.length})</h3>
                        <div className="flex items-center text-amber-400">
                          <span className="text-sm font-bold text-gray-600 mr-1">4.9</span>
                          {"★".repeat(5)}
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        {relevantReviews.map((rev) => (
                          <div key={rev.id} className="bg-white p-5 rounded-2xl border border-gray-100 shadow-xs">
                            <div className="flex justify-between items-start">
                              <div>
                                <span className="font-bold text-sm text-[#0B2545]">{rev.author}</span>
                                <span className="text-[10px] text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-sm font-bold ml-2">Verified Traveler</span>
                                <span className="block text-[10px] text-gray-400 mt-0.5">{rev.location} • {rev.date}</span>
                              </div>
                              <span className="text-amber-400 text-xs">{"★".repeat(rev.rating)}</span>
                            </div>
                            <p className="text-xs text-gray-600 leading-relaxed mt-3 italic">"{rev.comment}"</p>
                            
                            <div className="mt-3.5 flex items-center justify-between">
                              <span className="text-[10px] font-mono text-[#F4A261] font-bold">Tour: {tours.find(t=>t.id === rev.tourId)?.title}</span>
                              <button
                                onClick={() => handleLikeReview(rev.id)}
                                className={`text-[10px] font-bold px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-all cursor-pointer ${
                                  likedReviews[rev.id]
                                    ? "bg-[#E76F51]/10 text-[#E76F51]"
                                    : "bg-gray-50 hover:bg-gray-100 text-gray-400"
                                }`}
                              >
                                <span>👍 Helpful</span>
                                <span className="font-black">{rev.likes}</span>
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Footer booking trigger for modal */}
                  <div className="sticky bottom-0 bg-white border-t border-gray-100 p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div>
                      <span className="text-xs text-gray-400 block font-bold uppercase">Ready to join our community?</span>
                      <span className="text-lg font-black text-[#0B2545]">From KES {selectedTour.priceKES.toLocaleString()} / guest</span>
                    </div>
                    <div className="flex space-x-3">
                      <button
                        onClick={() => setSelectedTour(null)}
                        className="bg-gray-50 hover:bg-gray-100 text-gray-600 font-bold text-sm px-6 py-3 rounded-xl cursor-pointer"
                      >
                        Back
                      </button>
                      <button
                        id="details-book-spot-cta"
                        onClick={() => {
                          handleOpenBooking(selectedTour.id);
                        }}
                        className="bg-[#E76F51] hover:bg-[#C94A29] text-white font-bold text-sm px-8 py-3 rounded-xl shadow-lg shadow-orange-500/10 cursor-pointer"
                      >
                        Reserve Your Spot Now
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* OUR PROMISE TAB */}
        {activeSection === "promise" && (
          <div id="promise-section" className="animate-fadeIn max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div className="text-center mb-16">
              <span className="font-mono text-xs font-bold text-[#E76F51] uppercase tracking-[0.2em]">Our Ethics & Guarantees</span>
              <h1 className="text-3xl sm:text-4xl font-black text-[#0B2545] mt-3">The Lakeside Adventure Promise</h1>
              <p className="text-gray-600 mt-4 leading-relaxed max-w-2xl mx-auto">
                We design purpose-driven, carbon-neutral wellness travel that guarantees deep restoration, secure logistics, and mutual impact.
              </p>
            </div>

            {/* Core Commitments List */}
            <div className="space-y-8">
              {/* Card 1: Peace of Mind Booking */}
              <div className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm flex flex-col md:flex-row md:items-start gap-6">
                <div className="bg-orange-50 p-4 rounded-xl text-[#E76F51] shrink-0 w-fit">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[#0B2545]">Flexible Bookings & Easy Cancellations</h3>
                  <p className="text-gray-600 text-sm mt-3 leading-relaxed">
                    We understand life can be unpredictable. You can cancel any scheduled trip up to **48 hours** before departure for a full **100% cash refund** or choose a free reschedule. No questions asked.
                  </p>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-4 text-xs font-semibold text-gray-500">
                    <li className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-[#E76F51]" />
                      <span>100% Cash refund up to 48 hours</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-[#E76F51]" />
                      <span>Free infinite reschedules</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Card 2: Absolute Safety Protocol */}
              <div className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm flex flex-col md:flex-row md:items-start gap-6">
                <div className="bg-emerald-50 p-4 rounded-xl text-emerald-600 shrink-0 w-fit">
                  <Heart className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[#0B2545]">Physical Safety & Trauma-Informed Wellness</h3>
                  <p className="text-gray-600 text-sm mt-3 leading-relaxed">
                    Your physical and emotional safety is paramount. Every group is escorted by certified, first-aid trained adventure leads and followed closely by a mechanical safety support van stocked with clean water, emergency stretchers, and nutrient-dense energy snacks.
                  </p>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-4 text-xs font-semibold text-gray-500">
                    <li className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500" />
                      <span>Red Cross Certified First-Aid Leads</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500" />
                      <span>Fully loaded Safety Support Chase-Van</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Card 3: Deep Local Eco-Stewardship */}
              <div className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm flex flex-col md:flex-row md:items-start gap-6">
                <div className="bg-amber-50 p-4 rounded-xl text-[#F4A261] shrink-0 w-fit">
                  <Leaf className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[#0B2545]">Authentic, Indigenous Storytelling</h3>
                  <p className="text-gray-600 text-sm mt-3 leading-relaxed">
                    We never use corporate agency guides. You are guided by the local indigenous custodians of the lands, forests, and caves. By travelling with us, you directly fund fair wages (30% above industry standards) and localized community development trust funds.
                  </p>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-4 text-xs font-semibold text-gray-500">
                    <li className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-[#F4A261]" />
                      <span>100% Local Community Guides employed</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-[#F4A261]" />
                      <span>20% of every ticket funds local saplings</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Preparation Blueprint banner */}
            <div className="bg-[#0B2545] rounded-3xl p-8 sm:p-12 text-white text-center mt-12 space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-48 h-48 bg-[#E76F51]/10 rounded-full blur-2xl" />
              <h3 className="text-2xl font-black">Ready to disconnect? We hold your space.</h3>
              <p className="text-sm text-amber-50/70 max-w-xl mx-auto leading-relaxed">
                Take a leap. Turn off notifications. Let our local guides cook you delicious, fresh lakeside organic food while you listen to historic oral storytelling.
              </p>
              <button
                onClick={() => handleOpenBooking()}
                className="bg-[#E76F51] hover:bg-[#C94A29] text-white px-8 py-3.5 rounded-xl font-bold text-sm tracking-wide transition-all inline-block shadow-md cursor-pointer"
              >
                Reserve Space
              </button>
            </div>
          </div>
        )}

        {/* COMMUNITY & ECO IMPACT TAB */}
        {activeSection === "impact" && (
          <div id="impact-section" className="animate-fadeIn max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div className="text-center mb-16">
              <span className="font-mono text-xs font-bold text-emerald-600 uppercase tracking-[0.2em]">Our Impact Blueprint</span>
              <h1 className="text-3xl sm:text-4xl font-black text-[#0B2545] mt-3">We Travel with Purpose</h1>
              <p className="text-gray-600 mt-4 leading-relaxed max-w-2xl mx-auto">
                Lakeside Adventures is more than an agency. We are a registered Kisumu community trust committed to conservation, fair-wage employment, and supporting education.
              </p>
            </div>

            {/* Interactive sliders representing community impact metrics */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
              <div className="lg:col-span-2 bg-white p-8 rounded-3xl border border-gray-100 shadow-sm space-y-6">
                <h3 className="text-xl font-bold text-[#0B2545] flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-[#E76F51]" />
                  <span>Explore Our Interactive Future Impact Goals</span>
                </h3>
                <p className="text-xs text-gray-500">
                  Move the slider to see how increasing our community bookings helps us achieve our 5-year re-forestation and educational goals.
                </p>

                {/* Simulated calculator slider */}
                <div className="space-y-6 pt-4">
                  <div>
                    <div className="flex justify-between text-xs font-bold text-gray-500 uppercase mb-2">
                      <span>Monthly Community Bookings Goal</span>
                      <span className="text-[#E76F51]">~150 travelers</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="300"
                      defaultValue="150"
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        setStats({
                          treesPlanted: Math.round(val * 9.5),
                          wasteCollectedKG: Math.round(val * 4.5),
                          guidesSupported: Math.min(24, Math.round(val / 10) + 4),
                          communityScholars: Math.round(val / 18) + 1
                        });
                      }}
                      className="w-full accent-[#E76F51] cursor-pointer"
                    />
                  </div>

                  {/* Reactive Output Stats Display */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-100">
                      <span className="text-[10px] text-gray-400 font-bold block uppercase">Trees planted yearly</span>
                      <span className="text-2xl font-black text-[#0B2545]">{stats.treesPlanted}</span>
                    </div>
                    <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-100">
                      <span className="text-[10px] text-gray-400 font-bold block uppercase">Litter cleared yearly</span>
                      <span className="text-2xl font-black text-[#0B2545]">{stats.wasteCollectedKG} kg</span>
                    </div>
                    <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-100">
                      <span className="text-[10px] text-gray-400 font-bold block uppercase">Guiding salaries funded</span>
                      <span className="text-2xl font-black text-[#0B2545]">{stats.guidesSupported} local jobs</span>
                    </div>
                    <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-100">
                      <span className="text-[10px] text-gray-400 font-bold block uppercase">School scholarships funded</span>
                      <span className="text-2xl font-black text-[#0B2545]">{stats.communityScholars} children</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Highlighting Our Local Eco-Heroes */}
              <div className="bg-[#0B2545] text-white p-8 rounded-3xl space-y-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-amber-400/5 rounded-full blur-xl" />
                <h3 className="text-xl font-bold flex items-center space-x-2">
                  <Users className="w-5 h-5 text-[#F4A261]" />
                  <span>Support Your Guides</span>
                </h3>
                <p className="text-xs text-amber-50/70 leading-relaxed">
                  Our professional guides are native to Kakamega, Rusinga Island, and Yimbo. Leave them an encouraging message or tip that we route directly to them!
                </p>

                <form onSubmit={handleSendGuideMessage} className="space-y-4 pt-2">
                  <div>
                    <label className="block text-[10px] font-bold text-amber-50/60 uppercase mb-1">Select Guide</label>
                    <select
                      value={guideName}
                      onChange={(e) => setGuideName(e.target.value)}
                      className="w-full bg-white/10 border border-white/20 rounded-xl px-3 py-2 text-xs text-white outline-hidden focus:border-[#F4A261] cursor-pointer"
                    >
                      <option value="Aron" className="text-gray-800">Aron (Kakamega Lead naturalist)</option>
                      <option value="Millicent" className="text-gray-800">Millicent (Rusinga cultural host)</option>
                      <option value="Elder Joseph" className="text-gray-800">Elder Joseph (Got Ramogi Storyteller)</option>
                      <option value="Otieno" className="text-gray-800">Otieno (Nandi Mechanic & Cycle Lead)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-amber-50/60 uppercase mb-1">Encouragement Message</label>
                    <textarea
                      rows={3}
                      value={guideMessage}
                      onChange={(e) => setGuideMessage(e.target.value)}
                      placeholder="Write Aron or Millicent a friendly note..."
                      className="w-full bg-white/10 border border-white/20 rounded-xl px-3 py-2 text-xs text-white placeholder-white/30 focus:border-[#F4A261] outline-hidden"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#E76F51] hover:bg-[#C94A29] text-white text-xs font-bold py-2.5 rounded-xl transition-all shadow-sm"
                  >
                    Send message to guide
                  </button>
                </form>
              </div>
            </div>

            {/* Meet Our Community Guides Section */}
            <h3 className="text-2xl font-black text-[#0B2545] mb-8">Meet Your Host Leaders</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Profile 1 */}
              <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-xs">
                <div className="h-56 bg-gray-100 relative">
                  <img
                    src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=400&q=80"
                    alt="Aron"
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute bottom-4 left-4 bg-white/95 text-xs font-bold px-3 py-1 rounded-md text-[#0B2545]">
                    Forest Custodian
                  </span>
                </div>
                <div className="p-6 space-y-2">
                  <h4 className="font-extrabold text-lg text-[#0B2545]">Aron Shibonje</h4>
                  <p className="text-xs text-gray-500 italic">"I have guided in Kakamega Forest for 18 years. My family's dream is to see our grandchildren explore an uncompromised rainforest."</p>
                </div>
              </div>

              {/* Profile 2 */}
              <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-xs">
                <div className="h-56 bg-gray-100 relative">
                  <img
                    src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=400&q=80"
                    alt="Otieno"
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute bottom-4 left-4 bg-white/95 text-xs font-bold px-3 py-1 rounded-md text-[#0B2545]">
                    Nandi Cycle Lead
                  </span>
                </div>
                <div className="p-6 space-y-2">
                  <h4 className="font-extrabold text-lg text-[#0B2545]">Otieno Ndolo</h4>
                  <p className="text-xs text-gray-500 italic">"Cycling is a language of resilience. Leading cyclists down the Nandi Hills teaches us how to tackle steep challenges in our personal lives."</p>
                </div>
              </div>

              {/* Profile 3 */}
              <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-xs">
                <div className="h-56 bg-gray-100 relative">
                  <img
                    src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80"
                    alt="Millicent"
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute bottom-4 left-4 bg-white/95 text-xs font-bold px-3 py-1 rounded-md text-[#0B2545]">
                    Lakeside Storyteller
                  </span>
                </div>
                <div className="p-6 space-y-2">
                  <h4 className="font-extrabold text-lg text-[#0B2545]">Millicent Akumu</h4>
                  <p className="text-xs text-gray-500 italic">"Rusinga Island has stories that cure mental fatigue. Let me show you Mawanga Rock paintings and feed you authentic local lake delicacies."</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TRAVEL FAQS TAB */}
        {activeSection === "faqs" && (
          <div id="faqs-section" className="animate-fadeIn max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div className="text-center mb-16">
              <span className="font-mono text-xs font-bold text-[#E76F51] uppercase tracking-[0.2em]">Traveler Preparedness</span>
              <h1 className="text-3xl sm:text-4xl font-black text-[#0B2545] mt-3">Frequently Anticipated Concerns</h1>
              <p className="text-gray-600 mt-4 leading-relaxed max-w-2xl mx-auto">
                Got questions about travel logistics, dietary needs, or safety? We have compiled direct answers to keep you informed.
              </p>
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
              {["All", "Logistics", "Gear", "Wellness", "Impact", "Booking"].map((category) => (
                <button
                  key={category}
                  onClick={() => {
                    setActiveFaqCategory(category);
                    setExpandedFaqId(null);
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                    activeFaqCategory === category
                      ? "bg-[#0B2545] text-white shadow-md shadow-[#0B2545]/15"
                      : "bg-white border border-gray-200 text-gray-500 hover:text-[#0B2545] hover:bg-gray-50"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            {/* FAQ Accordion Layout */}
            <div className="space-y-4">
              {faqs
                .filter(faq => activeFaqCategory === "All" || faq.category === activeFaqCategory)
                .map((faq) => {
                  const isExpanded = expandedFaqId === faq.id;
                  return (
                    <div
                      key={faq.id}
                      className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-xs transition-all duration-200"
                    >
                      <button
                        onClick={() => setExpandedFaqId(isExpanded ? null : faq.id)}
                        className="w-full text-left px-6 py-5 flex items-center justify-between font-bold text-base text-[#0B2545] hover:text-[#E76F51] transition-all cursor-pointer"
                      >
                        <div className="flex items-center space-x-3 pr-4">
                          <HelpCircle className="w-5 h-5 text-[#F4A261] shrink-0" />
                          <span>{faq.question}</span>
                        </div>
                        <ChevronDown className={`w-5 h-5 text-gray-400 shrink-0 transition-transform ${isExpanded ? "rotate-180" : ""}`} />
                      </button>

                      {isExpanded && (
                        <div className="px-6 pb-6 pt-1 border-t border-gray-50 text-sm text-gray-600 leading-relaxed animate-fadeIn">
                          <p className="whitespace-pre-line">{faq.answer}</p>
                          <span className="inline-block mt-4 bg-amber-50 text-[#C94A29] px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider">
                            Topic: {faq.category}
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* MY TRIP PASSENGER DASHBOARD */}
        {activeSection === "my-bookings" && (
          <div id="my-bookings-section" className="animate-fadeIn max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div className="text-center mb-16">
              <span className="font-mono text-xs font-bold text-emerald-600 uppercase tracking-[0.2em]">Passenger Terminal</span>
              <h1 className="text-3xl sm:text-4xl font-black text-[#0B2545] mt-3">My Trip Boarding Passes</h1>
              <p className="text-gray-600 mt-4 leading-relaxed max-w-2xl mx-auto">
                Access your active boarding codes, view cancellation slips, and prepare your gear checklists prior to the departure.
              </p>
            </div>

            {bookings.length === 0 ? (
              <div id="empty-dashboard" className="text-center py-20 bg-white rounded-3xl border border-gray-150 shadow-sm p-8 max-w-xl mx-auto space-y-6">
                <Compass className="w-16 h-16 text-[#E76F51] mx-auto animate-pulse" />
                <h3 className="text-2xl font-bold text-[#0B2545]">No Active Bookings</h3>
                <p className="text-gray-500 text-sm leading-relaxed">
                  Your ticket registry is currently empty. Head over to our Adventures catalog, select an eco-wellness tour, and reserve your spot to generate a live digital boarding pass!
                </p>
                <button
                  onClick={() => setActiveSection("explore")}
                  className="bg-[#E76F51] hover:bg-[#C94A29] text-white font-bold px-6 py-3 rounded-xl text-sm tracking-wide shadow-md transition-all cursor-pointer inline-block"
                >
                  Explore Adventure Catalog
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-10">
                {bookings.map((bk) => (
                  <div
                    key={bk.id}
                    className="bg-white rounded-3xl border border-gray-150 overflow-hidden shadow-md flex flex-col lg:flex-row"
                  >
                    {/* Visual Segment */}
                    <div className="relative w-full lg:w-80 h-48 lg:h-auto bg-gray-100">
                      <img
                        src={bk.tourImage}
                        alt={bk.tourTitle}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-[#0B2545]/50 mix-blend-multiply" />
                      
                      {/* Booking confirmation badge */}
                      <span className="absolute top-4 left-4 bg-emerald-600 text-white text-xs font-bold px-3.5 py-1.5 rounded-xl shadow-md uppercase">
                        ✓ {bk.status}
                      </span>
                    </div>

                    {/* Content Segment */}
                    <div className="p-8 flex-grow flex flex-col justify-between space-y-6">
                      <div className="space-y-4">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                          <div>
                            <span className="text-[10px] font-mono text-[#E76F51] font-bold uppercase">{bk.tourType}</span>
                            <h3 className="text-xl font-bold text-[#0B2545] mt-1 leading-tight">{bk.tourTitle}</h3>
                          </div>
                          
                          {/* Boarding code */}
                          <div className="bg-amber-50 border border-[#E9C46A] p-3.5 rounded-xl text-center shrink-0">
                            <span className="text-[10px] font-bold text-[#0B2545]/40 block uppercase">Boarding Pass</span>
                            <span className="font-mono text-base font-extrabold text-[#C94A29] tracking-wider">{bk.id}</span>
                          </div>
                        </div>

                        {/* Booking Specifics */}
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-gray-100">
                          <div>
                            <span className="text-[10px] text-gray-400 font-bold uppercase block">Departure Date</span>
                            <span className="text-sm font-extrabold text-gray-700">{new Date(bk.date).toLocaleDateString()}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-gray-400 font-bold uppercase block">Pass Count</span>
                            <span className="text-sm font-extrabold text-gray-700">{bk.guests} Guest(s)</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-gray-400 font-bold uppercase block">Amount Paid</span>
                            <span className="text-sm font-extrabold text-[#E76F51]">KES {bk.totalCostKES.toLocaleString()}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-gray-400 font-bold uppercase block">Payment Channel</span>
                            <span className="text-sm font-extrabold text-gray-700">{bk.paymentMethod} Express</span>
                          </div>
                        </div>

                        {/* Passenger Details */}
                        <div className="p-4 bg-gray-50 rounded-xl text-xs space-y-1.5">
                          <span className="font-bold text-[#0B2545] uppercase tracking-wider block text-[10px]">Passenger Manifest</span>
                          <p className="text-gray-600"><strong className="font-semibold text-gray-700">Lead Passenger:</strong> {bk.fullName}</p>
                          <p className="text-gray-600"><strong className="font-semibold text-gray-700">Contact:</strong> {bk.email} • {bk.phone}</p>
                          {bk.specialRequests && <p className="text-gray-600 italic"><strong className="font-semibold text-gray-700">Requests:</strong> "{bk.specialRequests}"</p>}
                        </div>
                      </div>

                      {/* Interactive Receipt Actions */}
                      <div className="pt-4 border-t border-gray-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 text-xs">
                        <p className="text-gray-500 italic">
                          *Show this digital boarding code at the Impala Sanctuary Hub near Kisumu gate 30 mins before departure.
                        </p>
                        
                        <div className="flex space-x-2 shrink-0">
                          <button
                            onClick={() => {
                              if (confirm("Are you sure you want to cancel this booking? Full refund will be automatically routed back to your payment channel under our Our Promise guarantee.")) {
                                setBookings(bookings.filter(b => b.id !== bk.id));
                                alert(`Booking ${bk.id} has been cancelled. Full KES ${bk.totalCostKES.toLocaleString()} refund has been routed back to your original payment channel.`);
                              }
                            }}
                            className="bg-red-50 hover:bg-red-100 text-red-700 font-bold px-4 py-2 rounded-xl transition-all cursor-pointer"
                          >
                            Cancel Ticket
                          </button>
                          <button
                            onClick={() => {
                              alert(`Receipt details printed for booking ${bk.id}. Sent copy to ${bk.email}!`);
                            }}
                            className="bg-gray-100 hover:bg-gray-200 text-[#0B2545] font-bold px-4 py-2 rounded-xl transition-all cursor-pointer"
                          >
                            Print Receipt
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Simulated Booking checkout Modal (Directly addresses video segment 2, 3, and 5) */}
      {bookingModalOpen && (
        <div id="booking-modal-overlay" className="fixed inset-0 z-50 bg-[#0B2545]/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white w-full max-w-xl rounded-3xl overflow-hidden shadow-2xl relative animate-slideUp">
            
            {/* Header */}
            <div className="bg-[#0B2545] p-6 text-white relative">
              <button
                onClick={() => setBookingModalOpen(false)}
                className="absolute top-6 right-6 text-white/80 hover:text-white hover:scale-105 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
              <h3 className="text-xl font-bold tracking-tight">Eco-Wellness Trip Registration</h3>
              <p className="text-xs text-amber-50/60 mt-1">Book directly. All transactions fund tree propagation and fair-wage community guides.</p>
            </div>

            {/* Simulated Payment Step: Form and Passenger setup */}
            {paymentStep === "form" && (
              <form onSubmit={handleCheckout} className="p-6 sm:p-8 space-y-6">
                
                {/* Select Tour Option */}
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">
                    Select Your Adventure
                  </label>
                  <select
                    id="checkout-select-tour"
                    value={bookingTourId}
                    onChange={(e) => setBookingTourId(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 focus:border-[#E76F51] rounded-xl px-4 py-3 text-sm text-gray-800 font-semibold outline-hidden cursor-pointer"
                  >
                    {tours.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.title} (KES {t.priceKES.toLocaleString()})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Date & Guests counter */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">
                      Departure Date
                    </label>
                    <input
                      id="checkout-date-picker"
                      type="date"
                      value={bookingDate}
                      onChange={(e) => setBookingDate(e.target.value)}
                      required
                      className="w-full bg-gray-50 border border-gray-200 focus:border-[#E76F51] rounded-xl px-4 py-3 text-sm text-gray-800 font-semibold outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">
                      Number of Guests
                    </label>
                    <div className="flex items-center space-x-2 bg-gray-50 border border-gray-200 rounded-xl px-2 py-1.5 h-[46px] justify-between">
                      <button
                        type="button"
                        onClick={() => setBookingGuests(Math.max(1, bookingGuests - 1))}
                        className="bg-white border border-gray-150 text-[#0B2545] p-1.5 rounded-lg hover:bg-gray-100 cursor-pointer"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="text-sm font-black text-[#0B2545] w-8 text-center">{bookingGuests}</span>
                      <button
                        type="button"
                        onClick={() => setBookingGuests(Math.min(12, bookingGuests + 1))}
                        className="bg-white border border-gray-150 text-[#0B2545] p-1.5 rounded-lg hover:bg-gray-100 cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Passenger Credentials */}
                <div className="space-y-4 pt-4 border-t border-gray-100">
                  <span className="text-xs font-bold text-gray-500 uppercase tracking-wider block">Lead Passenger Details</span>
                  
                  <div>
                    <input
                      id="checkout-full-name"
                      type="text"
                      placeholder="Your Full Name"
                      value={bookingName}
                      onChange={(e) => setBookingName(e.target.value)}
                      required
                      className="w-full bg-gray-50 border border-gray-200 focus:border-[#E76F51] rounded-xl px-4 py-3 text-sm outline-hidden"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <input
                      id="checkout-email"
                      type="email"
                      placeholder="Email Address"
                      value={bookingEmail}
                      onChange={(e) => setBookingEmail(e.target.value)}
                      required
                      className="w-full bg-gray-50 border border-gray-200 focus:border-[#E76F51] rounded-xl px-4 py-3 text-sm outline-hidden"
                    />
                    <input
                      id="checkout-phone"
                      type="tel"
                      placeholder="M-Pesa / Phone Number"
                      value={bookingPhone}
                      onChange={(e) => setBookingPhone(e.target.value)}
                      required
                      className="w-full bg-gray-50 border border-gray-200 focus:border-[#E76F51] rounded-xl px-4 py-3 text-sm outline-hidden"
                    />
                  </div>
                  
                  <div>
                    <textarea
                      rows={2}
                      placeholder="Special Requests (dietary needs, accessibility requests, etc.)"
                      value={specialRequests}
                      onChange={(e) => setSpecialRequests(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 focus:border-[#E76F51] rounded-xl px-4 py-2 text-sm outline-hidden"
                    />
                  </div>
                </div>

                {/* Payment Channels */}
                <div className="space-y-4 pt-4 border-t border-gray-100">
                  <span className="text-xs font-bold text-gray-500 uppercase tracking-wider block">Select Secure Payment Gateway</span>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <label
                      className={`flex items-center space-x-3 p-3.5 rounded-xl border cursor-pointer select-none transition-all ${
                        paymentMethod === "MPESA"
                          ? "bg-emerald-50/50 border-emerald-400 text-emerald-800 font-bold"
                          : "bg-white border-gray-150 text-gray-500"
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        checked={paymentMethod === "MPESA"}
                        onChange={() => setPaymentMethod("MPESA")}
                        className="sr-only"
                      />
                      <Phone className="w-5 h-5 shrink-0" />
                      <span className="text-xs">M-Pesa STK Push</span>
                    </label>

                    <label
                      className={`flex items-center space-x-3 p-3.5 rounded-xl border cursor-pointer select-none transition-all ${
                        paymentMethod === "CARD"
                          ? "bg-blue-50 border-blue-400 text-blue-800 font-bold"
                          : "bg-white border-gray-150 text-gray-500"
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        checked={paymentMethod === "CARD"}
                        onChange={() => setPaymentMethod("CARD")}
                        className="sr-only"
                      />
                      <CreditCard className="w-5 h-5 shrink-0" />
                      <span className="text-xs">Credit/Debit Card</span>
                    </label>
                  </div>

                  {paymentMethod === "MPESA" ? (
                    <div className="bg-emerald-50/20 p-4 rounded-xl border border-emerald-100 space-y-2">
                      <span className="text-[10px] text-emerald-800 font-bold uppercase tracking-wider block">M-Pesa Express Payment Details</span>
                      <p className="text-[11px] text-gray-500">We will trigger a secure Safaricom STK PIN popup directly onto this phone number.</p>
                      <input
                        id="checkout-mpesa-number"
                        type="tel"
                        placeholder="M-Pesa Number (e.g. 0712345678)"
                        value={mpesaPhone}
                        onChange={(e) => setMpesaPhone(e.target.value)}
                        required={paymentMethod === "MPESA"}
                        className="w-full bg-white border border-emerald-200 focus:border-emerald-500 rounded-lg px-3.5 py-2.5 text-xs outline-hidden font-mono"
                      />
                    </div>
                  ) : (
                    <div className="bg-blue-50/10 p-4 rounded-xl border border-blue-100 space-y-3">
                      <span className="text-[10px] text-blue-800 font-bold uppercase tracking-wider block">Credit Card Details (Simulated Gateway)</span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <input
                          type="text"
                          placeholder="Card Number"
                          className="w-full bg-white border border-blue-100 rounded-lg px-3 py-2 text-xs outline-hidden"
                          defaultValue="4111 2222 3333 4444"
                        />
                        <div className="flex space-x-2">
                          <input
                            type="text"
                            placeholder="MM/YY"
                            className="w-1/2 bg-white border border-blue-100 rounded-lg px-3 py-2 text-xs outline-hidden text-center"
                            defaultValue="12/28"
                          />
                          <input
                            type="password"
                            placeholder="CVV"
                            className="w-1/2 bg-white border border-blue-100 rounded-lg px-3 py-2 text-xs outline-hidden text-center"
                            defaultValue="123"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Subtotal & Reservation submission */}
                <div className="pt-6 border-t border-gray-100 space-y-4">
                  <div className="flex justify-between items-baseline">
                    <span className="text-xs text-gray-400 font-bold uppercase">Estimated Total Due:</span>
                    <span className="text-3xl font-black text-[#0B2545]">KES {currentTotalKES.toLocaleString()}</span>
                  </div>

                  <button
                    id="submit-payment-checkout"
                    type="submit"
                    className="w-full bg-[#E76F51] hover:bg-[#C94A29] text-white font-bold py-4 rounded-xl shadow-lg shadow-orange-500/10 transition-all text-center block cursor-pointer"
                  >
                    Authorize Reservation & Pay
                  </button>
                </div>
              </form>
            )}

            {/* Simulated Payment Step: STK Prompt/Processing */}
            {paymentStep === "processing" && (
              <div className="p-12 text-center space-y-6">
                <div className="w-16 h-16 border-4 border-[#E76F51] border-t-transparent rounded-full animate-spin mx-auto" />
                <h4 className="text-xl font-bold text-[#0B2545]">Contacting Safe Gateways...</h4>
                <p className="text-gray-500 text-xs leading-relaxed max-w-sm mx-auto">
                  We are securely routing your registration credentials to the merchant network. Please hold onto this screen while we request authorization.
                </p>
              </div>
            )}

            {/* Simulated Payment Step: Waiting for M-Pesa PIN */}
            {paymentStep === "pin_wait" && (
              <div className="p-12 text-center space-y-6 animate-pulse">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto text-3xl">
                  📲
                </div>
                <h4 className="text-xl font-bold text-emerald-800">Check Your Mobile Device!</h4>
                <p className="text-xs text-gray-500 max-w-xs mx-auto leading-relaxed">
                  We have triggered an M-Pesa STK Express Push request directly to your mobile number <strong className="font-semibold">{mpesaPhone || bookingPhone}</strong>. <br /><br />
                  Please enter your 4-digit Safaricom PIN to complete the eco-wellness reservation!
                </p>
              </div>
            )}

            {/* Simulated Payment Step: Success Boarding Code Display */}
            {paymentStep === "success" && (
              <div className="p-12 text-center space-y-6 animate-fadeIn">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto text-3xl">
                  ✓
                </div>
                <h4 className="text-2xl font-black text-[#0B2545]">Reservation Completed!</h4>
                <p className="text-xs text-gray-500 max-w-sm mx-auto leading-relaxed">
                  Thank you, <strong className="font-semibold">{bookingName}</strong>! Your boarding passes and preparatory gear checklists have been securely stored in the Passenger terminal.
                </p>

                <div className="bg-amber-50 border border-[#E9C46A] p-4 rounded-2xl max-w-xs mx-auto">
                  <span className="text-[10px] text-gray-400 font-bold block uppercase">Digital Boarding Code</span>
                  <span className="font-mono text-xl font-black text-[#C94A29] tracking-widest uppercase">
                    {bookings[0]?.id || "BK-ACTIVE"}
                  </span>
                </div>

                <button
                  id="checkout-view-ticket-btn"
                  onClick={handleFinishBookingFlow}
                  className="bg-[#0B2545] hover:bg-slate-800 text-white font-bold px-8 py-3 rounded-xl text-sm transition-all shadow-md cursor-pointer inline-block"
                >
                  View My Tickets
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Structured Trust Footer */}
      <footer id="site-footer" className="bg-[#0B2545] text-white pt-20 pb-12 border-t border-white/5 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 pb-16 border-b border-white/5">
            {/* Logo and Pitch */}
            <div className="space-y-4">
              <div className="inline-block p-1 bg-white rounded-2xl">
                {/* Embedded Brand emblem */}
                <svg width="48" height="48" viewBox="0 0 400 400" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M200 10 L370 108 L370 292 L200 390 L30 292 L30 108 Z" fill="#0B2545" stroke="#E9C46A" strokeWidth="6"/>
                  <path d="M200 15 L360 108 L360 292 L200 385 L40 292 L40 108 Z" fill="#C94A29"/>
                  <text x="200" y="295" fill="#FFFFFF" fontSize="44" fontWeight="800" textAnchor="middle">LAKESIDE</text>
                </svg>
              </div>
              <p className="text-xs text-amber-50/60 leading-relaxed font-medium">
                Lakeside Adventure Community is a Kisumu-based eco-adventure and wellness initiative that brings people together through meaningful outdoor experiences across East Africa.
              </p>
              <div className="text-[10px] text-amber-50/40">
                <span>© 2026 Lakeside Adventure Community. All rights reserved.</span>
              </div>
            </div>

            {/* Quick sections */}
            <div className="space-y-4">
              <h4 className="text-sm font-bold uppercase tracking-wider text-[#F4A261]">Our Expeditions</h4>
              <ul className="space-y-2.5 text-xs text-amber-50/70">
                <li><button onClick={() => { setActiveSection("explore"); setSelectedType("Hike"); }} className="hover:text-white transition-all cursor-pointer">🥾 Forest Canopy Hikes</button></li>
                <li><button onClick={() => { setActiveSection("explore"); setSelectedType("Cycling"); }} className="hover:text-white transition-all cursor-pointer">🚴 Mountain Cycling Escarpments</button></li>
                <li><button onClick={() => { setActiveSection("explore"); setSelectedType("Island Escape"); }} className="hover:text-white transition-all cursor-pointer">🏝️ Lake Victoria Island Escapes</button></li>
                <li><button onClick={() => { setActiveSection("explore"); setSelectedType("Regional Trip"); }} className="hover:text-white transition-all cursor-pointer">🗺️ Regional Cultural Expeditions</button></li>
              </ul>
            </div>

            {/* Travel Policies / Video Step 4 */}
            <div className="space-y-4">
              <h4 className="text-sm font-bold uppercase tracking-wider text-[#F4A261]">Travel Guarantee</h4>
              <ul className="space-y-2.5 text-xs text-amber-50/70">
                <li><button onClick={() => setActiveSection("promise")} className="hover:text-white transition-all cursor-pointer">🛡️ Flexible Cancellation Policy</button></li>
                <li><button onClick={() => setActiveSection("promise")} className="hover:text-white transition-all cursor-pointer">🏥 Trauma-Informed Wellness Leads</button></li>
                <li><button onClick={() => setActiveSection("impact")} className="hover:text-white transition-all cursor-pointer">🌱 Re-forestation Initiative</button></li>
                <li><button onClick={() => setActiveSection("faqs")} className="hover:text-white transition-all cursor-pointer">🙋 Dietary, Packing & Accessibility FAQ</button></li>
              </ul>
            </div>

            {/* Newsletter Local SEO */}
            <div className="space-y-4">
              <h4 className="text-sm font-bold uppercase tracking-wider text-[#F4A261]">Community Hub</h4>
              <p className="text-xs text-amber-50/60 leading-relaxed">
                Located near Kisumu Impala Sanctuary Gate, Kisumu, Kenya. Stop by for hot ginger tea, guide storytelling circles, and to pick up map blueprints!
              </p>
              <div className="bg-white/5 p-3 rounded-xl border border-white/5 text-[11px] font-semibold text-[#E9C46A]">
                📍 Impala Sanctuary Gate, Kisumu, KE
              </div>
            </div>
          </div>

          <div className="pt-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 text-[10px] text-amber-50/40">
            <div>
              <span>Designed with the Kisumu Community Trust. Powered by Antigravity Core.</span>
            </div>
            <div className="flex space-x-4">
              <a href="#" className="hover:underline">Privacy Charter</a>
              <a href="#" className="hover:underline">Eco-Sovereignty Statement</a>
              <a href="#" className="hover:underline">Safaricom Merchant API Security</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
